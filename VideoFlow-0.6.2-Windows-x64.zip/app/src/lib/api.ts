import type {AppState, Project, ProjectPatch, Job, Provider, Integration} from '../types';

export class APIError extends Error {constructor(message: string, public status: number, public requestId?: string, public details?: unknown) {super(message);}}
let csrf = '';
export async function request<T>(url: string, init: RequestInit = {}): Promise<T> {
  const controller = new AbortController(), timer = setTimeout(() => controller.abort(new DOMException('Сервер не ответил за 60 секунд', 'TimeoutError')), 60000);
  try {
    const headers = new Headers(init.headers);
    if (!(init.body instanceof FormData) && !headers.has('Content-Type')) headers.set('Content-Type','application/json');
    if (!headers.has('X-CSRF-Token')) headers.set('X-CSRF-Token',csrf);
    const response = await fetch(`/api${url}`, {...init, headers, signal: init.signal ? AbortSignal.any([init.signal, controller.signal]) : controller.signal});
    if (response.status === 204) return undefined as T;
    const value: unknown = await response.json();
    if (!response.ok) { const error = value as {message?: string; requestId?: string; details?: unknown}; throw new APIError(error.message || `HTTP ${response.status}`, response.status, error.requestId, error.details); }
    return value as T;
  } catch (error) {
    if (error instanceof APIError || (error instanceof DOMException && ['AbortError','TimeoutError'].includes(error.name))) throw error;
    throw new APIError('Нет связи с локальным сервером. Проверьте, запущен ли Backend.', 0);
  } finally { clearTimeout(timer); }
}
const post = <T>(url: string, body: unknown = {}) => request<T>(url, {method: 'POST', body: JSON.stringify(body)});
export const api = {
  async state() { const value = await request<AppState>('/state'); csrf = value.csrf; return value; },
  project: (id: string) => request<Project>(`/projects/${id}`),
  create: (data: unknown) => post<{project: Project; warnings: string[]}>('/projects', data),
  patch: (id: string, revision: number, patch: ProjectPatch) => request<Project>(`/projects/${id}`, {method: 'PATCH', body: JSON.stringify({...patch, revision})}),
  delete: (id: string) => request<void>(`/projects/${id}`, {method: 'DELETE', body: JSON.stringify({confirm: id})}),
  connect: (provider: Provider, key?: string) => post<Integration>(`/integrations/${provider}`, key === undefined ? {} : {key}),
  settings: (keys: Partial<Record<Provider,string>>) => request('/settings', {method: 'PATCH', body: JSON.stringify({keys})}),
  generate: (id: string, stage: string, itemId: string, newTake = false, acknowledgeUncertain = false) => post<{key: string}>(`/projects/${id}/generate`, {stage, itemId, newTake, acknowledgeUncertain}),
  textPlan: (id: string) => request<{blocks: number; total: number}>(`/projects/${id}/text/plan`),
  text: (id: string, data: {action: 'rewrite' | 'translate'; language?: string; model: string; resumeKey?: string; newTake?: boolean; acknowledgeUncertain?: boolean}) => post(`/projects/${id}/text`, data),
  applyText: (id: string, operationKey: string) => post<Project>(`/projects/${id}/text/apply`, {operationKey}),
  cancel: (id: string, itemId?: string) => post(`/projects/${id}/cancel`, {itemId}),
  jobs: (id: string) => request<Job[]>(`/projects/${id}/jobs`),
  styles: (id: string, scenePrompt: string, newSet = false) => post(`/projects/${id}/styles`,{scenePrompt,newSet}),
  styleVideos: (id: string) => post(`/projects/${id}/styles/videos`),
  styleSelect: (id: string, setId: string, variantId: string) => post<Project>(`/projects/${id}/styles/select`,{setId,variantId}),
  styleRetry: (id: string, setId: string, variantId: string, stage: string, acknowledgeUncertain: boolean) => post(`/projects/${id}/styles/retry`,{setId,variantId,stage,acknowledgeUncertain}),
  styleClear: (id: string) => post<Project>(`/projects/${id}/styles/clear`),
  styleCancel: (id: string) => post(`/projects/${id}/styles/cancel`),
  visualReference: (id: string, revision: number, data?: string, remove = false) => post<Project>(`/projects/${id}/visual-reference`,{revision,data,remove}),
  audio: (id: string, scope: string, data?: string, remove = false) => post<Project>(`/projects/${id}/audio`, {scope, data, remove}),
  alignment: (id: string, scope: string) => post(`/projects/${id}/alignment`, {scope}),
  subtitles: (id: string) => post<Project>(`/projects/${id}/subtitles`),
  render: (id: string) => post(`/projects/${id}/render`),
  studio: (projectId: string) => post<{url: string}>('/studio', {projectId}),
  restore: (data: string) => post<Project>('/restore', {data}),
};
export function fileBase64(file: File, maximum = 20 * 1024 * 1024): Promise<string> {
  if (file.size > maximum) return Promise.reject(new Error(`Файл больше ${maximum / 1024 / 1024} МБ`));
  return new Promise((resolve, reject) => { const reader = new FileReader(); reader.onerror = () => reject(new Error('Не удалось прочитать файл')); reader.onload = () => resolve(String(reader.result).split(',')[1]); reader.readAsDataURL(file); });
}
export const assetURL = (path: string) => `/files/${path.split('/').map(encodeURIComponent).join('/')}`;
