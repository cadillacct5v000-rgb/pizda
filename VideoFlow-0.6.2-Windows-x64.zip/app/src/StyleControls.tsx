import {useState} from 'react';
import type {Project,ProjectPatch} from './types';
import {api} from './lib/api';
interface Props {project: Project; busy: boolean; save: (patch: ProjectPatch) => Promise<void>; run: (action: () => Promise<unknown>) => Promise<void>;}
const statuses: Record<string,string> = {draft:'Не создано',queued:'В очереди',creating:'Отправка',running:'Генерация',ready:'Готово',paused:'Приостановлено',cancelled:'Остановлено',error:'Ошибка',uncertain:'Исход отправки неизвестен'};
export default function StyleControls({project,busy,save,run}: Props) {
  const [scene,setScene] = useState(project.styleSet?.scenePrompt || project.frames[0]?.imagePrompt || '');
  const set = project.styleSet, working = !!set?.variants.some((v) => [v.imageStatus,v.videoStatus].some((s) => ['queued','creating','running'].includes(s)));
  async function create(newSet = false) {
    if (!confirm((set?.variants.some((v) => [v.imageStatus,v.videoStatus].includes('uncertain')) ? 'Прошлая отправка могла быть оплачена. Проверьте кабинет fal.ai. ' : '') + 'Создать три варианта стиля на одной тестовой сцене? До трёх новых платных изображений через fal.ai. Готовые совпадающие превью переиспользуются. Кадры ролика и озвучка не запускаются.')) return;
    window.dispatchEvent(new Event('video-flow-flush')); await save({models:{falImageModel:project.models.falImageModel}});
    await api.styles(project.id,scene,newSet);
  }
  return <section aria-label="Три варианта стиля" className="style-picker">
    <h3>Наш стиль · три варианта по исходнику</h3>
    <p>Одна тестовая сцена, одна манера исходника и три авторских направления. Сравните изображения или короткие видеопревью и выберите вариант для следующих кадров.</p>
    <label className="field">Тестовая сцена для сравнения<textarea aria-label="Тестовая сцена для сравнения" value={scene} maxLength={10000} disabled={busy || working} onChange={(e) => setScene(e.target.value)}/></label>
    <div className="toolbar"><button disabled={busy || working || !project.visualReference} onClick={() => {void run(() => create());}}>Создать или продолжить 3 варианта</button>
      {set && <button disabled={busy || working} onClick={() => {void run(() => create(true));}}>Создать новую тройку</button>}
      {set?.variants.every((v) => v.image) && <button disabled={busy || working} onClick={() => {void run(async() => {if(confirm('Оживить каждое превью на 5 секунд? До трёх новых платных видеозапросов fal.ai. Готовые совпадающие клипы переиспользуются.')) await api.styleVideos(project.id);});}}>Оживить 3 превью по 5 секунд</button>}
      {working && <button disabled={busy} onClick={() => {void run(() => api.styleCancel(project.id));}}>Остановить превью стилей</button>}
    </div>
    {!project.visualReference && <p>Сначала загрузите исходный образец выше и выберите Nano Banana 2 или Pro.</p>}
    {project.channelStyle && <p role="status">Стиль для новых кадров: <strong>{project.channelStyle.label}</strong>. <a href={`/files/${project.channelStyle.reference.path}`} download="channel-style.png">Сохранить образец для других роликов</a> <button disabled={busy} onClick={() => {void run(() => api.styleClear(project.id));}}>Вернуться к исходному образцу</button></p>}
    {set && <div className="style-variants">{set.variants.map((variant) => {
      const selected = project.channelStyle?.id === `${set.id}:${variant.id}`;
      return <article key={`${set.id}:${variant.id}`} className={selected ? 'style-variant selected' : 'style-variant'}>
        <h4>{variant.label}</h4>
        {variant.image && <img src={`/files/${variant.image.path}`} alt={variant.label}/>}
        {variant.video && <video controls preload="metadata" src={`/files/${variant.video.path}`} aria-label={`Видеопревью ${variant.label}`}/>}
        <p role="status">Изображение: {statuses[variant.imageStatus] || variant.imageStatus} · Видео: {statuses[variant.videoStatus] || variant.videoStatus}</p>
        {variant.error && <p className="error">{variant.error}</p>}
        <button className={selected ? 'primary' : ''} disabled={busy || working || !variant.image} aria-pressed={selected} onClick={() => {void run(() => api.styleSelect(project.id,set.id,variant.id));}}>{selected ? 'Выбран для ролика' : `Выбрать вариант ${variant.id.toUpperCase()}`}</button>
        {(['image','video'] as const).map((stage) => ['error','uncertain'].includes(variant[`${stage}Status`]) && <button key={stage} disabled={busy || working} onClick={() => {void run(async() => {const uncertain = variant[`${stage}Status`] === 'uncertain';if(confirm(uncertain ? 'Прошлый запрос мог быть оплачен. Проверьте fal.ai. Подтвердить новую платную отправку только этого превью?' : 'Отправить новое платное превью только этого варианта?')) await api.styleRetry(project.id,set.id,variant.id,stage,uncertain);});}}>Повторить {stage === 'image' ? 'изображение' : 'видео'} варианта</button>)}
      </article>;
    })}</div>}
    <p>Выбор сохраняется с проектом и передаётся Nano Banana как изображение-образец и описание манеры. Готовые кадры остаются; для их изменения создайте новые варианты. Для повторяющихся персонажей используйте тот же выбранный образец в следующих проектах.</p>
  </section>;
}
