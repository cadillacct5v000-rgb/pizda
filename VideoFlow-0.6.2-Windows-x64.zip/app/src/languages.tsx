const languages = [['ru','Русский'],['ro','Румынский'],['es','Испанский'],['pt-BR','Португальский — Бразилия'],['pt-PT','Португальский — Португалия'],['en','Английский'],['de','Немецкий'],['fr','Французский'],['it','Итальянский']];
export function LanguageSelect({value, change, label = 'Язык сценария'}: {value: string; label?: string; change: (value: string) => void}) {
  return <label className="field">{label}<select aria-label={label} value={value} onChange={(event) => change(event.target.value)}>
    {!languages.some(([code]) => code === value) && <option value={value}>{value}</option>}
    {languages.map(([code, label]) => <option value={code} key={code}>{label}</option>)}
  </select></label>;
}
