import {useState} from 'react';
import type {AppState, Job, Project, ProjectPatch} from './types';
import {api} from './lib/api';
import {LanguageSelect} from './languages';

type Action = 'rewrite' | 'translate';
interface Props {project: Project; state: AppState; jobs: Job[]; busy: boolean; save: (patch: ProjectPatch) => Promise<void>; run: (action: () => Promise<unknown>) => Promise<void>; refresh: () => Promise<void>;}
const labels: Record<string,string> = {queued:'В очереди',creating:'Отправка',running:'Claude работает',ready:'Вариант готов',paused:'Приостановлено после перезапуска',cancelled:'Остановлено',error:'Ошибка',uncertain:'Результат отправки неизвестен'};

export default function TextControls({project,state,jobs,busy,save,run,refresh}: Props) {
  const [language,setLanguage] = useState(project.language), [shown,setShown] = useState(20);
  const job = jobs.filter((item) => item.stage === 'text').sort((a,b) => (a.updatedAt || '').localeCompare(b.updatedAt || '')).at(-1), proposal = project.textProposal;
  const working = jobs.some((item) => item.stage === 'text' && ['queued','creating','running'].includes(item.status));
  async function begin(action: Action, retry = false, resume = false) {
    const fromJob = retry || resume;
    window.dispatchEvent(new Event('video-flow-flush'));
    const model = fromJob ? job?.model || project.models.falTextModel : project.models.falTextModel;
    await save({models:{falTextModel:model}}); // joins pending editor saves before taking the server snapshot
    const plan = await api.textPlan(project.id);
    const target = fromJob ? job?.language || language : action === 'translate' ? language : undefined;
    const message = retry && job?.status === 'uncertain'
      ? 'Прошлый запрос мог быть оплачен. Проверьте кабинет fal.ai. Повторить незавершённую часть и продолжить обработку? Возможна повторная оплата.'
      : `Обработать ${plan.blocks} реплик через Claude? До ${plan.total} запросов. Новые запросы оплачиваются в fal.ai; готовые части переиспользуются. Текущий текст изменится только после применения варианта.`;
    if (!confirm(message)) return;
    await api.text(project.id,{action,language:target,model,resumeKey:fromJob ? job?.key : undefined,newTake:retry,acknowledgeUncertain:retry && job?.status === 'uncertain'});
    await refresh();
  }
  async function apply() {
    if (!proposal || !confirm('Применить вариант Claude? Для изменённых реплик потребуется новая озвучка и пересборка. Загруженное общее/сценовое аудио будет отвязано, если его текст изменился. Готовые изображения и файлы медиа останутся на диске.')) return;
    window.dispatchEvent(new Event('video-flow-flush'));
    await save({models:{falTextModel:project.models.falTextModel}});
    await api.applyText(project.id,proposal.operationKey); await refresh();
  }
  return <section className="card">
    <h2>Claude · сценарий и перевод</h2>
    <p>Claude работает через ваш ключ fal.ai. Он улучшает подачу или адаптирует реплики под другой язык, сохраняя их связь со сценами. Озвучка, изображения и видео автоматически не запускаются.</p>
    <div className="columns"><label className="field">Текстовая модель<select aria-label="Текстовая модель" disabled={busy || working} value={project.models.falTextModel} onChange={(event) => {void run(() => save({models:{falTextModel:event.target.value}}));}}>
      {!state.textModels.some((model) => model.value === project.models.falTextModel) && <option value={project.models.falTextModel}>{project.models.falTextModel}</option>}
      {state.textModels.map((model) => <option key={model.value} value={model.value}>{model.label}</option>)}
    </select></label><LanguageSelect label="Язык перевода" value={language} change={setLanguage}/></div>
    <div className="toolbar"><button disabled={busy || working || !project.blocks.some((block) => block.text.trim())} onClick={() => {void run(() => begin('rewrite'));}}>Улучшить сценарий</button><button disabled={busy || working || !project.blocks.some((block) => block.text.trim())} onClick={() => {void run(() => begin('translate'));}}>Перевести и адаптировать</button>
      {job && ['paused','cancelled','error'].includes(job.status) && <button disabled={busy || working} onClick={() => {void run(() => begin(job.action || 'rewrite',false,true));}}>Продолжить сохранённую обработку</button>}
      {job && ['error','uncertain'].includes(job.status) && <button disabled={busy || working} onClick={() => {void run(() => begin(job.action || 'rewrite',true));}}>Новая отправка незавершённой части</button>}
      {working && <button disabled={busy} onClick={() => {void run(() => api.cancel(project.id,'script'));}}>Остановить Claude</button>}
    </div>
    {job && <div role="status"><p>{labels[job.status] || job.status} · частей: {job.completed || 0}/{job.total || 0}{job.appliedAt && ' · применён'}</p>{job.error && <p className="error">{job.error}</p>}{job.cancelUnconfirmed && <p>Удалённая отмена не подтверждена; проверьте кабинет fal.ai.</p>}</div>}
    {proposal && <div className="text-proposal"><h3>Сравнение · {proposal.blocks.length} реплик · {proposal.language}</h3><p>Язык и текущий текст ещё не изменены. Надписи внутри готовых изображений модель здесь не перерисовывает.</p>
      {proposal.blocks.slice(0,shown).map((block,index) => <details key={`${proposal.operationKey}:${block.id}`} open={index === 0}><summary>Реплика {index + 1} · {project.scenes.find((scene) => scene.id === project.blocks.find((source) => source.id === block.id)?.sceneId)?.title}</summary><div className="columns"><div><small>Сейчас</small><p>{project.blocks.find((source) => source.id === block.id)?.text}</p></div><div><small>Вариант Claude</small><p>{block.text}</p></div></div></details>)}
      {shown < proposal.blocks.length && <button onClick={() => setShown(shown + 20)}>Показать ещё 20 реплик</button>}
      <button className="primary" disabled={busy || working} onClick={() => {void run(apply);}}>Применить вариант Claude</button>
    </div>}
  </section>;
}
