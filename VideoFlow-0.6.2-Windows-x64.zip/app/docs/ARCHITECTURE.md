# Архитектура

```mermaid
flowchart LR
  UI[React 19 / Vite / TypeScript] --> API[Express 5 / loopback]
  API --> DB[(SQLite WAL)]
  API --> FS[Media + manifests]
  API --> Q[voice 1 / images 1 / video 2]
  Q --> P[Lumean / fal.ai]
  API --> W[Lazy Whisper CPU]
  API --> R[Remotion + FFmpeg]
```

```mermaid
stateDiagram-v2
  draft --> voiceover
  voiceover --> storyboard
  storyboard --> images
  images --> animation: enabled
  images --> subtitles: static
  animation --> subtitles
  subtitles --> assembly
  assembly --> ready
  assembly --> error
  error --> assembly: исправление / повтор
```

SQLite — источник истины. STRICT таблицы, prepared statements, WAL, synchronous FULL, foreign keys, busy timeout. Запись новой ревизии коммитится перед атомарным manifest. Если зеркало не записалось, health сообщает предупреждение; запуск восстанавливает зеркала из БД. PATCH со старой ревизией возвращает 409. Мутация без await синхронна в одном процессе Node.

Файлы внутри projects UUID; ссылки относительные. Runtime/config отделены от приложения в customer package. Бэкапы БД — один проверенный снимок на день, последние семь. ZIP проекта включает перечисленные артефакты и manifest; restore проверяет структуры и медиа, назначает новый UUID и пересоздаёт производные субтитры/рендер.

Операция сохраняется до POST. Внешний ID сохраняется сразу после ответа; fal.ai сохраняет request_id и адреса задачи сразу после ответа на единственный платный POST. Повтор присоединяется к очереди по operation key. После рестарта создающие задачи становятся uncertain/paused; продолжение запускается пользователем. Это предотвращает скрытую новую оплату, но не гарантирует, что провайдер вернёт средства при отмене.

Редактирование imagePrompt очищает image/video; motion/camera/weight — video/render; текст — соответствующий голос, alignment и render. Новая озвучка сбрасывает зависящие клипы. Смена FPS повторно нормализует существующую внешнюю задачу, когда её результат ещё доступен, без нового create.

## ADR 1: локальный монолит

Один процесс упрощает установку, хранение токенов и согласованность. Компромисс — один пользователь и один локальный сервер; сетевой многопользовательский режим отсутствует.

## ADR 2: embedded SQLite

Не требует отдельной службы БД. Транзакции и ревизии защищают от потерянных сохранений. БД и файловое зеркало не могут коммититься одной транзакцией; порядок и восстановление описаны выше.

## Замена провайдера из документа

Вместо SYNTX используется fal.ai. Модели читаются через `https://api.fal.ai/v1/models` с проверкой конкретных поддержанных endpoint IDs. Для генерации используется `https://queue.fal.run`: один POST, сохранение request_id/status_url/response_url/cancel_url, далее только status/result GET. URL задачи проверяется до передачи ключа; ключ не передаётся на CDN результата. Отмена — PUT сохранённого cancel URL; промежуточная отмена не выдаётся за подтверждённую.

Для image-to-video локальный PNG загружается через официальный @fal-ai/client. SDK используется только для storage, платный Queue submit выполняется нашим адаптером без автоматических повторов. Upload/подготовка предшествуют состоянию creating и записи возможной оплаты. Неудачная загрузка не выдаётся за неизвестный результат платной генерации. Сторонний storage и старая ссылка изображения не требуются.

Whisper работает в отдельном worker_threads процессе с кэшем и deadline. Studio получает отдельную временную public-папку и props текущего проекта; дочерний HTTP-сервер ограничен loopback и завершается при shutdown.

Текстовая обработка выполняется `text.mjs` через fal `openrouter/router`: отдельная очередь limit=1, Claude Opus/Sonnet/Haiku, неизменяемый source hash, батчи по ID реплик, durable request IDs и JSON-квитанции перед валидацией. Платный POST не повторяется автоматически; оплата отражается отдельной ledger entry на попытку. Результат сначала хранится как proposal, применение сохраняет старый проект в text-history, ID и изображения; инвалидирует затронутое аудио/клипы/субтитры/рендер. Начало процесса — готовый сценарий/DOCX; анализ/скачивание YouTube пока отсутствуют.

Визуальные адаптеры0.5: Nano Banana2/Pro используют aspect_ratio/resolution/context Gemini; Kling3 — start_image_url, SeedancePro — image_url. Исходный образец хранится в project.visualReference, проверяется/decode через FFmpeg, включается в media ZIP/restore, учитывается в fingerprint новых генераций. Смена образца не удаляет готовые изображения. Загрузка в fal выполняется до creating/оплаты и использует официальный storage SDK.

В0.6 styles.mjs хранит styleSet (source/model/scenePrompt/3variants) и channelStyle (selected image reference + instruction). Очередь styles имеет limit1 и отдельные операции style-image/style-video, сохраняет ID перед polling и медиаквитанцию до декодирования. Глобальные HTTP guards исключают одновременную работу оплаченных media/style очередей. Новые изображения generationService используют activeStyle(), поэтому выбор входит в fingerprint и проверку позднего результата. Архив включает изображения/клипы вариантов и выбранный образец; восстановление валидирует медиа и назначает новую тройку UUID.

Аудит0.6.2: целочисленные интервалы общего аудио сначала распределяются по текстовым блокам, затем внутри связанных кадров. Caption pages сохраняют весь текст; внутренние интервалы многостраничной реплики отмечены estimated. Legacy manifest import выполняется однократно (schema migration2). Удаление staging в .deleted предшествует DELETE SQL, rollback возвращает каталог при SQL-ошибке; cleanup вне /files повторяется при старте. Render/Studio локально приводят старые клипы к текущим длительностям без новой платной генерации.
