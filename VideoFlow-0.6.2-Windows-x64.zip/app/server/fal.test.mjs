import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,readFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {configuration} from './config.mjs';
import {providerClients} from './providers.mjs';
import {falClient,falModels,falQueueRoute} from './fal-client.mjs';
import {createProject,patchProject,importRows,scriptRows} from './domain.mjs';
import {validateNarration} from './language.mjs';

const catalog=JSON.parse(readFileSync(new URL('./fixtures/fal-models.json',import.meta.url),'utf8'));
const signal=()=>new AbortController().signal;
const job={request_id:'job-123',status_url:'https://queue.fal.run/fal-ai/wan/requests/job-123/status',response_url:'https://queue.fal.run/fal-ai/wan/requests/job-123',cancel_url:'https://queue.fal.run/fal-ai/wan/requests/job-123/cancel'};
function fixture(t){const root=mkdtempSync(path.join(tmpdir(),'fal-contract-'));t.after(()=>rmSync(root,{recursive:true,force:true}));const config=configuration({},root);config.providers.fal.key='private-test-key';return config;}
function requestFixture(calls){return async(_name,route,options={})=>{calls.push({route,options});if(route.startsWith('/v1/models'))return catalog;if(options.method==='POST')return job;return {status:'COMPLETED'};};}

test('document defaults keep Lumean and use fal for images/video; retired providers are not active',(t)=>{
  const config=fixture(t),p=createProject();assert.deepEqual(Object.keys(config.providers).sort(),['fal','lumean']);
  assert.equal(p.models.voiceProvider,'lumean');assert.equal(p.models.imageProvider,'fal');assert.equal(p.models.videoProvider,'fal');
  assert.throws(()=>patchProject(p,{models:{imageProvider:'elysium'}}));
});
test('fal catalog separates compatible image/video endpoints and rejects incompatible models before POST',async(t)=>{
  const config=fixture(t),calls=[],client=falClient(config,requestFixture(calls),async()=>{},fetch,{upload:async()=>''});
  assert.equal(falModels(catalog).filter((m)=>m.kind==='image').length,4);assert.equal(falModels(catalog).filter((m)=>m.kind==='video').length,3);
  await assert.rejects(client.validate({stage:'image',model:'wan/v2.6/image-to-video',prompt:'Ocean'},signal()),{status:409});
  assert.equal(calls.length,0);
});
test('image input is landscape/medium/one PNG and the accepted ID is checkpointed',async(t)=>{
  const config=fixture(t),calls=[],client=falClient(config,requestFixture(calls),async()=>{});
  const payload={stage:'image',model:'openai/gpt-image-2',prompt:'Ocean'};
  await client.validate(payload,signal());const prepared=await client.prepare(payload,signal());
  assert.deepEqual(prepared.input,{prompt:'Ocean',image_size:'landscape_16_9',num_images:1,output_format:'png',quality:'medium',background:'opaque'});
  let saved;const accepted=await client.create(prepared,signal(),(value)=>{saved=value;});assert.equal(saved,accepted.id);assert.equal(JSON.parse(saved).requestId,'job-123');
  assert.equal(calls.filter((c)=>c.options.method==='POST').length,1);
});
test('video directly uploads the exact local source, uses image_url and disables prompt expansion',async(t)=>{
  const config=fixture(t),bytes=Buffer.from('source-bytes'),uploaded=[];
  const client=falClient(config,requestFixture([]),async()=>{},fetch,{upload:async(data)=>{uploaded.push(data);return 'https://fal.media/source.png';}});
  const payload={stage:'video',model:'wan/v2.6/image-to-video',prompt:'Gentle movement',image:bytes.toString('base64'),duration:7};
  await client.validate(payload,signal());const prepared=await client.prepare(payload,signal());
  assert.deepEqual(uploaded,[bytes]);assert.equal(prepared.input.image_url,'https://fal.media/source.png');assert.equal(prepared.input.duration,'10');assert.equal(prepared.input.resolution,'1080p');assert.equal(prepared.input.enable_prompt_expansion,false);
});
test('poll/download resumes a saved ID without submitting again; result type is checked',async(t)=>{
  const config=fixture(t),calls=[],downloads=[];
  const request=async(_name,route,options={})=>{calls.push({route,options});return route.endsWith('/status')?{status:'COMPLETED'}:{images:[{url:'https://fal.media/result.png'}]};};
  const client=falClient(config,request,async(url)=>{downloads.push(url);return Buffer.from('image');});
  const externalId=JSON.stringify({requestId:job.request_id,statusURL:job.status_url,responseURL:job.response_url,cancelURL:job.cancel_url});
  const status=await client.status(externalId,signal());assert.equal(status.status,'succeeded');assert.equal((await client.result(status,'image',signal())).toString(),'image');
  assert.equal(calls.some((c)=>c.options.method==='POST'),false);assert.deepEqual(downloads,['https://fal.media/result.png']);
});
test('queue URLs cannot redirect the API key to another host or mismatched request',(t)=>{
  const config=fixture(t);assert.equal(falQueueRoute(job.status_url,config,'job-123','/status'),'/fal-ai/wan/requests/job-123/status');
  for(const url of ['https://attacker.example/requests/job-123/status','http://queue.fal.run/requests/job-123/status','https://queue.fal.run/requests/other/status','https://user:pass@queue.fal.run/requests/job-123/status'])assert.throws(()=>falQueueRoute(url,config,'job-123','/status'));
});
test('cancellation sends PUT to saved cancel URL and pending cancellation is not called confirmed',async(t)=>{
  const config=fixture(t),calls=[],client=falClient(config,async(_name,route,options)=>{calls.push({route,options});return {status:'CANCELLATION_REQUESTED'};},async()=>{});
  await assert.rejects(client.cancel(JSON.stringify({requestId:job.request_id,cancelURL:job.cancel_url})),{status:409});assert.equal(calls[0].options.method,'PUT');
});
test('native HTTP uses Key auth, never retries a billable submit, and errors redact secrets',async(t)=>{
  const config=fixture(t),calls=[];
  const clients=providerClients(config,async(url,options)=>{calls.push({url,options});if(options.method==='POST')throw new Error('lost response');return Response.json(catalog);});
  const result=await clients.fal.check();assert.ok(result.models.length>0);assert.ok(calls.every((c)=>c.options.headers.Authorization==='Key private-test-key'));
  const prepared=await clients.fal.prepare({stage:'image',model:'openai/gpt-image-2',prompt:'Ocean'},signal());
  await assert.rejects(clients.fal.create(prepared,signal()),(error)=>!JSON.stringify(error).includes('private-test-key'));assert.equal(calls.filter((c)=>c.options.method==='POST').length,1);
});
test('official storage SDK uploads bytes without sending Key authorization to signed CDN URL',async(t)=>{
  const config=fixture(t),calls=[];
  const clients=providerClients(config,async(url,options)=>{calls.push({url:String(url),options});if(String(url).includes('/storage/upload/initiate'))return Response.json({upload_url:'https://storage.example/upload',file_url:'https://fal.media/source.png'});if(String(url)==='https://storage.example/upload')return new Response('',{status:200});throw new Error('unexpected request');});
  const result=await clients.fal.prepare({stage:'video',model:'wan/v2.6/image-to-video',prompt:'Motion',image:Buffer.from('source').toString('base64'),duration:5},signal());
  assert.equal(result.input.image_url,'https://fal.media/source.png');const put=calls.find((c)=>c.options.method==='PUT');assert.ok(put);assert.equal(new Headers(put.options.headers).has('authorization'),false);
});
test('target-language guard and minimal audio invalidation remain intact',()=>{
  for(const language of ['ro','es','pt-BR','pt-PT'])assert.throws(()=>validateNarration('Косатка главный хищник океана и охотится на тюленей.',language),{status:409});
  const p=importRows(createProject(),scriptRows('Старый текст'));p.blocks[0].audio={path:'audio.mp3',provider:'lumean'};p.frames[0].image={path:'image.png'};const updated=patchProject(p,{language:'ro'});assert.equal(updated.blocks[0].audio,null);assert.equal(updated.frames[0].image.path,'image.png');
});
test('Nano Banana 2/Pro use Gemini image contract at 2K and pass actual reference bytes',async(t)=>{
  for(const model of ['fal-ai/nano-banana-pro','fal-ai/nano-banana-2']){
    const config=fixture(t),calls=[],uploads=[],client=falClient(config,requestFixture(calls),async()=>{},fetch,{upload:async(bytes)=>{uploads.push(bytes);return 'https://fal.media/reference.png';}});
    const payload={stage:'image',model,prompt:'A whale in our channel style',reference:Buffer.from('reference-bytes').toString('base64')};await client.validate(payload,signal());const prepared=await client.prepare(payload,signal());
    assert.deepEqual(prepared.input,{prompt:payload.prompt,aspect_ratio:'16:9',resolution:'2K',num_images:1,output_format:'png',context:[{type:'image',image_url:'https://fal.media/reference.png'}],system_prompt:'Use the supplied image as a visual style reference: preserve its palette, linework, shading and recurring character design. Draw the new scene described in the prompt; do not reproduce the reference composition or its embedded text.'});assert.equal(uploads[0].toString(),'reference-bytes');assert.equal('image_size' in prepared.input,false);
    await client.create(prepared,signal());assert.equal(calls.filter((c)=>c.options.method==='POST').length,1);assert.equal(calls.find((c)=>c.options.method==='POST').route,`/${model}`);
    const plain=await client.prepare({...payload,reference:undefined},signal());assert.equal('context' in plain.input,false);
  }
});
test('Seedance and Kling use distinct source-image/duration fields and disable generated audio',async(t)=>{
  const config=fixture(t),calls=[],client=falClient(config,requestFixture(calls),async()=>{},fetch,{upload:async()=> 'https://fal.media/source.png'});
  const base={stage:'video',prompt:'Slow movement',image:Buffer.from('source').toString('base64'),duration:7.2};
  const seedance=await client.prepare({...base,model:'fal-ai/bytedance/seedance/v1/pro/image-to-video'},signal());assert.deepEqual(seedance.input,{prompt:base.prompt,image_url:'https://fal.media/source.png',aspect_ratio:'16:9',resolution:'1080p',duration:'8',camera_fixed:false});
  const kling=await client.prepare({...base,model:'fal-ai/kling-video/v3/pro/image-to-video'},signal());assert.deepEqual(kling.input,{prompt:base.prompt,start_image_url:'https://fal.media/source.png',duration:'8',generate_audio:false});
  for(const prepared of [seedance,kling]){await client.validate({...base,model:prepared.model},signal());await client.create(prepared,signal());}
  assert.equal(calls.filter((c)=>c.options.method==='POST').length,2);
  for(const [model,duration]of [['fal-ai/bytedance/seedance/v1/pro/image-to-video',13],['fal-ai/kling-video/v3/pro/image-to-video',16]])await assert.rejects(client.validate({...base,model,duration},signal()),{status:409});
  await assert.rejects(client.validate({stage:'image',model:'openai/gpt-image-2',prompt:'Whale',reference:'YWJj'},signal()),{status:409});
});
test('audit 17/24: an unavailable unrelated catalog does not block compatible image generation',async(t)=>{
 const config=fixture(t),calls=[],client=falClient(config,async(_name,route,options={})=>{
  calls.push({route,options});if(route.includes('openrouter'))throw Object.assign(Error('offline'),{status:503,details:{providerStatus:503}});return catalog;
 },async()=>{});const state=await client.check();assert.ok(state.models.some((m)=>m.kind==='image'));assert.ok(state.warnings.length);calls.length=0;await client.validate({stage:'image',model:'fal-ai/nano-banana-pro',prompt:'A whale'},signal());assert.equal(calls.length,1);assert.ok(calls[0].route.includes('nano-banana-pro'));
});
