import {setTimeout as pause} from 'node:timers/promises';
import {lookup} from 'node:dns/promises';
import {isIP, BlockList} from 'node:net';
import https from 'node:https';
import {ensure, AppError, redact} from './core.mjs';
import {falClient} from './fal-client.mjs';

const denied = new BlockList(), denied6 = new BlockList();
for (const [network, prefix] of [['0.0.0.0',8],['10.0.0.0',8],['100.64.0.0',10],['127.0.0.0',8],['169.254.0.0',16],['172.16.0.0',12],['192.0.0.0',24],['192.168.0.0',16],['198.18.0.0',15],['224.0.0.0',4],['240.0.0.0',4]]) denied.addSubnet(network, prefix);
for (const [network, prefix] of [['::',128],['::1',128],['fc00::',7],['fe80::',10],['ff00::',8],['::ffff:0:0',96]]) denied6.addSubnet(network, prefix, 'ipv6');
export async function checkDownloadURL(input, resolve = lookup) {
  const url = new URL(input);
  ensure(url.protocol === 'https:' && !url.username && !url.password && (!url.port || url.port === '443') && !isIP(url.hostname.replace(/[[\]]/g, '')), 'Небезопасная ссылка результата', 502);
  const addresses = await resolve(url.hostname, {all: true, verbatim: true});
  ensure(addresses.length && addresses.every(({address, family}) => family === 6 ? !denied6.check(address, 'ipv6') : !denied.check(address)), 'Ссылка результата ведёт в локальную сеть', 502);
  return url;
}
async function pinnedDownload(url, signal) {
  let addresses;
  const target = await checkDownloadURL(url, async (...args) => { addresses = await lookup(...args); return addresses; });
  const address = addresses[0];
  return new Promise((resolve, reject) => {
    const request = https.get(target, {signal, lookup: (_hostname, options, callback) => options.all ? callback(null, [address]) : callback(null, address.address, address.family)}, (response) => {
      const headers = new Headers(); for (const [key,value] of Object.entries(response.headers)) if (value !== undefined) headers.set(key, Array.isArray(value) ? value.join(',') : value);
      resolve({ok: response.statusCode >= 200 && response.statusCode < 300, status: response.statusCode, headers, body: response});
    }); request.on('error', reject);
  });
}
export function providerClients(config, fetcher = fetch, dependencies = {}) {
  const secrets = () => Object.values(config.providers).map((p) => p.key);
  async function request(name, route, {method = 'GET', body, signal, binary = false, form, timeout = config.httpTimeout, base} = {}) {
    const provider = config.providers[name]; ensure(provider?.key, `Подключите ${name} в настройках`, 409);
    const headers = name === 'fal' ? {Authorization: `Key ${provider.key.replace(/^Key\s+/i, '').trim()}`} : {'X-API-KEY': provider.key};
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    const deadline = AbortSignal.timeout(timeout), combined = AbortSignal.any([deadline, ...(signal ? [signal] : [])]);
    const attempts = method === 'GET' ? 3 : 1;
    for (let attempt = 0; attempt < attempts; attempt++) {
      try {
        combined.throwIfAborted();
        const response = await fetcher((base || provider.base) + route, {method, headers, body: form || (body === undefined ? undefined : JSON.stringify(body)), signal: combined, redirect: 'error'});
        if (!response.ok) {
          // Never expose upstream error payloads: they can echo keys or narration.
          const status = response.status;
          throw new AppError(status === 401 || status === 403 ? 401 : 502, `${name}: HTTP ${status}${status === 401 || status === 403 ? ' — проверьте ключ и разрешения' : ''}`, {providerStatus: status});
        }
        try {return binary ? Buffer.from(await response.arrayBuffer()) : await response.json();}
        catch {throw new AppError(502, `${name}: некорректный или незавершённый ответ сервиса`, {kind: 'invalid_response'});}
      } catch (failure) {
        if (signal?.aborted) throw signal.reason;
        const transient = !failure.status || failure.details?.kind === 'invalid_response' || [429,500,502,503,504].includes(failure.details?.providerStatus);
        if (!combined.aborted && transient && attempt + 1 < attempts) {await pause(250 * 2 ** attempt + Math.floor(Math.random() * 100), undefined, {signal: combined}); continue;}
        if (failure instanceof AppError) throw failure;
        throw new AppError(502, `Нет ответа от ${name}`, {kind: 'network', cause: redact(failure.message, secrets())});
      }
    }
  }

  async function download(url, signal, maximum = 512 * 1024 * 1024) {
    let target = url;
    for (let redirects = 0; redirects <= 3; redirects++) {
      const response = await pinnedDownload(target, AbortSignal.any([AbortSignal.timeout(300000), ...(signal ? [signal] : [])]));
      if ([301,302,303,307,308].includes(response.status)) { response.body.destroy(); target = new URL(response.headers.get('location'), target).href; continue; }
      ensure(response.ok && response.body, `Не удалось скачать результат: HTTP ${response.status}`, 502);
      ensure(!Number.isFinite(Number(response.headers.get('content-length'))) || Number(response.headers.get('content-length')) <= maximum, 'Результат превышает лимит', 502);
      const chunks = []; let size = 0;
      try { for await (const chunk of response.body) { size += chunk.byteLength; ensure(size <= maximum, 'Результат превышает лимит', 502); chunks.push(Buffer.from(chunk)); } }
      catch (error) { response.body.destroy(); throw error; }
      ensure(size > 0, 'Пустой результат', 502); return Buffer.concat(chunks);
    }
    throw new AppError(502, 'Слишком много перенаправлений результата');
  }
  const lumean = {
    async validate(payload) {
      const response = await request('lumean', `/templates/${encodeURIComponent(payload.template_id)}`);
      const language = response.data?.config?.tts_settings?.language_code;
      if (language && payload.language) ensure(language.toLowerCase().split('-')[0] === payload.language.toLowerCase().split('-')[0], 'Язык шаблона Lumean отличается от языка сценария. Выберите шаблон для нужного языка.', 409);
    },
    async check() {
      async function pages(route, size, query = '') {
        const items = [];
        for (let page = 1; page <= 100; page++) {
          const response = await request('lumean', `${route}?page=${page}&per_page=${size}${query}`), data = response.data;
          ensure(Array.isArray(data?.items), 'Lumean вернул некорректную страницу каталога', 502);
          items.push(...data.items);
          if (data.last_page != null ? page >= data.last_page : data.items.length < size) return items;
        }
        throw new AppError(502, 'Каталог Lumean превышает лимит страниц');
      }
      const [templates,wallets] = await Promise.all([pages('/templates',30,'&type=tts'),pages('/wallets',100)]);
      return {templates: templates.map(({id,name,service_key,config}) => ({id,name,service:service_key,language:config?.tts_settings?.language_code || null})), balance: wallets.map(({balance_formatted,locked_balance_formatted,asset}) => ({available:balance_formatted,locked:locked_balance_formatted,unit:asset?.code}))};
    },
    async create(payload, signal) { const {template_id,input_text} = payload; const result = await request('lumean', '/orders', {method: 'POST', body: {template_id,input_text}, signal}); return result.data || result; },
    async status(externalId, signal) { const result = await request('lumean', `/orders/${encodeURIComponent(externalId)}`, {signal}); return result.data || result; },
    async cancel(externalId) { return request('lumean', `/orders/${encodeURIComponent(externalId)}/cancel`, {method: 'POST', signal: AbortSignal.timeout(15000)}); },
    async result(status, _stage, signal) {
      const file = status.result?.files?.[0]; ensure(typeof file === 'string', 'Lumean не вернул итоговый аудиофайл', 502);
      const result = await request('lumean', '/storage/url', {method: 'POST', body: {path: file}, signal});
      ensure(result.data?.url || result.url, 'Lumean не вернул ссылку на файл', 502);
      return (dependencies.download || download)(result.data?.url || result.url, signal);
    },
    async alignment(status, signal) {
      const file = status.result?.service_files?.find((item) => typeof item === 'string' && /alignment[^/]*\.json$/i.test(item));
      if (!file) return null;
      const result = await request('lumean', '/storage/url', {method: 'POST', body: {path: file}, signal});
      const url = result.data?.url || result.url; ensure(url, 'Нет ссылки на alignment Lumean', 502);
      const response = JSON.parse((await (dependencies.download || download)(url, signal, 8 * 1024 * 1024)).toString());
      const data = response.alignment || response;
      ensure(Array.isArray(data.characters) && Array.isArray(data.character_start_times_seconds) && Array.isArray(data.character_end_times_seconds) && data.characters.length === data.character_start_times_seconds.length && data.characters.length === data.character_end_times_seconds.length, 'Неизвестный формат alignment Lumean; используйте локальный Whisper', 502);
      const chunks = []; let word;
      for (let index = 0; index < data.characters.length; index++) {
        const text = data.characters[index], start = data.character_start_times_seconds[index], end = data.character_end_times_seconds[index];
        ensure(typeof text === 'string' && Number.isFinite(start) && Number.isFinite(end) && start >= 0 && end >= start, 'Некорректные тайминги alignment Lumean', 502);
        if (/[\p{L}\p{N}\p{M}]/u.test(text)) {
          if (!word) word = {text: '', timestamp: [start,end]};
          word.text += text; word.timestamp[1] = end;
        } else if (word) {chunks.push(word); word = null;}
      }
      if (word) chunks.push(word); return chunks;
    },
  };
  const fal = falClient(config, request, dependencies.download || download, fetcher, dependencies);
  return {lumean, fal, request, download};
}
export async function poll(client, externalId, config, signal, onStatus = () => {}) {
  const deadline = Date.now() + config.jobTimeout;
  let failures = 0;
  while (Date.now() < deadline) {
    signal.throwIfAborted();
    try {
      const status = await client.status(externalId, signal); failures = 0; onStatus(status);
      if (['succeeded', 'completed', 'result_delivered'].includes(status.status)) return status;
      if (['failed', 'error', 'cancelled', 'canceled', 'partial'].includes(status.status)) throw new AppError(422, `Провайдер завершил задачу со статусом ${status.status}`, {terminal: true});
    } catch (error) {
      if (signal.aborted) throw signal.reason;
      if (error.details?.terminal || error.status === 401 || error.details?.providerStatus === 404) throw error;
      failures++; if (failures >= 8) throw error;
    }
    await pause(Math.min(config.poll * 2 ** Math.min(failures, 3), 60000), undefined, {signal});
  }
  throw new AppError(504, 'Время ожидания истекло. Внешний ID сохранён; повтор продолжит проверку существующей задачи.');
}
