import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,readFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {setTimeout as pause} from 'node:timers/promises';
import {styleService,activeStyle} from './styles.mjs';
import {generationService} from './generation.mjs';
import {createProject,importRows,scriptRows} from './domain.mjs';
import {openStore} from './database.mjs';
import {configuration} from './config.mjs';
import {atomic,within} from './core.mjs';
import {processFile,ffmpeg} from './media.mjs';
import {exportArchive,restoreArchive} from './archive.mjs';
import {createApp} from './app.mjs';
async function settle(service){for(let i=0;i<1500;i++){if(!service.stats().keys.length)return;await pause(5);}throw Error('Styles queue timeout');}
async function setup(t){
 const root=mkdtempSync(path.join(tmpdir(),'flow-styles-')),config=configuration({DATA_DIR:root},root),store=openStore(root);config.poll=1;config.jobTimeout=1000;config.providers.fal.key='mock-style-key';
 const png=path.join(root,'source.png'),mp4=path.join(root,'preview.mp4');await processFile(ffmpeg,['-y','-f','lavfi','-i','color=c=teal:s=320x180','-frames:v','1','-threads','1',png]);await processFile(ffmpeg,['-y','-f','lavfi','-i','color=c=teal:s=320x180:d=0.1','-an','-c:v','libx264','-threads','1',mp4]);
 const p=importRows(createProject(),scriptRows('A whale in the ocean.'));p.frames[0].imagePrompt='A whale in the ocean';p.frames[0].approved=true;p.visualReference={path:`${p.id}/images/reference.png`,duration:null};atomic(within(store.projectsDir,p.visualReference.path),readFileSync(png));const project=store.put(p,null);
 const inputs=[],client={validate:async()=>{},prepare:async(p)=>p,create:async(p,_signal,checkpoint)=>{const id=String(inputs.push(p));checkpoint(id);return {id};},status:async(id)=>({status:'succeeded',id}),result:async(_s,stage)=>readFileSync(stage==='image'?png:mp4),cancel:async()=>{}};
 const service=styleService(store,client,config),resources=[];t.after(async()=>{for(const cleanup of resources.reverse())await cleanup();await service.close();store.close();rmSync(root,{recursive:true,force:true});});return {root,config,store,project,inputs,client,service,png,cleanup:(fn)=>resources.push(fn)};
}
test('three reference-based images and video previews preserve the storyboard and selection drives future images',async(t)=>{
 const f=await setup(t),before=f.store.get(f.project.id);f.service.create(f.project.id,{scenePrompt:'A whale exploring the ocean'});await settle(f.service);let p=f.store.get(f.project.id);assert.equal(p.styleSet.variants.length,3);assert.ok(p.styleSet.variants.every((v)=>v.image&&v.imageStatus==='ready'));assert.equal(f.inputs.length,3);assert.ok(f.inputs.every((p)=>p.reference===readFileSync(f.png).toString('base64')));assert.equal(new Set(f.inputs.map((p)=>p.prompt)).size,3);assert.deepEqual(p.frames,before.frames);assert.deepEqual(p.blocks,before.blocks);
 f.service.create(f.project.id,{scenePrompt:'A whale exploring the ocean'});await settle(f.service);assert.equal(f.inputs.length,3);
 const set=p.styleSet;f.service.select(p.id,{setId:set.id,variantId:'b'});p=f.store.get(p.id);assert.equal(p.channelStyle.id,`${set.id}:b`);assert.equal(activeStyle(p).reference.path,set.variants[1].image.path);
 const gen=generationService(f.store,{fal:f.client},f.config);gen.enqueue(p.id,'image',p.frames[0].id);for(let i=0;i<1000&&gen.stats().some((q)=>q.active||q.pending);i++)await pause(5);await gen.close();assert.match(f.inputs[3].prompt,/Channel art direction:/);assert.equal(f.inputs[3].reference,readFileSync(within(f.store.projectsDir,set.variants[1].image.path)).toString('base64'));
 f.service.videos(p.id);await settle(f.service);p=f.store.get(p.id);assert.ok(p.styleSet.variants.every((v)=>v.video&&v.video.duration===5));assert.ok(f.inputs.slice(4).every((p)=>p.duration===5&&p.stage==='video'));assert.equal(f.inputs.length,7);
 const restored=await restoreArchive(f.store,await exportArchive(f.store,p.id));assert.ok(restored.channelStyle.reference.path.startsWith(restored.id+'/'));assert.equal(restored.styleSet.variants.length,3);assert.ok(restored.styleSet.variants.every((v)=>v.image&&v.video));assert.equal(restored.channelStyle.instruction,p.channelStyle.instruction);
});
test('failed preview resumes known external ID; unknown POST is blocked and only explicit variant retry pays again',async(t)=>{
 const f=await setup(t),result=f.client.result;let failed=true;f.client.result=async(s,stage)=>{if(s.id==='2'&&failed)throw Error('Temporary download failure');return result(s,stage);};f.service.create(f.project.id,{scenePrompt:'A whale scene'});await settle(f.service);assert.equal(f.inputs.length,3);assert.equal(f.store.get(f.project.id).styleSet.variants[1].imageStatus,'error');failed=false;f.service.create(f.project.id,{scenePrompt:'A whale scene'});await settle(f.service);assert.equal(f.inputs.length,3);assert.equal(f.store.get(f.project.id).styleSet.variants[1].imageStatus,'ready');
 const create=f.client.create;let sends=0;f.client.create=async(p,s,c)=>{sends++;if(sends===1)throw Error('Unknown POST outcome');return create(p,s,c);};f.service.create(f.project.id,{scenePrompt:'A whale scene',newSet:true});await settle(f.service);let p=f.store.get(f.project.id);assert.equal(p.styleSet.variants[0].imageStatus,'uncertain');assert.throws(()=>f.service.create(p.id,{scenePrompt:'A whale scene'}),{status:409});assert.throws(()=>f.service.retry(p.id,{setId:p.styleSet.id,variantId:'a'}),{status:409});const count=f.inputs.length;f.service.retry(p.id,{setId:p.styleSet.id,variantId:'a',acknowledgeUncertain:true});await settle(f.service);p=f.store.get(p.id);assert.equal(f.inputs.length,count+1);assert.equal(p.styleSet.variants[0].imageStatus,'ready');assert.equal(p.cost.length,7);
});
test('style selection is explicit and new sets keep the previous chosen style until selection',async(t)=>{
 const f=await setup(t);assert.throws(()=>f.service.select(f.project.id,{setId:'missing',variantId:'a'}),{status:409});f.service.create(f.project.id,{scenePrompt:'A whale scene'});await settle(f.service);let p=f.store.get(f.project.id);assert.equal(p.channelStyle,undefined);f.service.select(p.id,{setId:p.styleSet.id,variantId:'c'});const selected=f.store.get(p.id).channelStyle;f.service.create(p.id,{scenePrompt:'Another whale scene',newSet:true});await settle(f.service);p=f.store.get(p.id);assert.deepEqual(p.channelStyle,selected);assert.throws(()=>f.service.select(p.id,{setId:'old-set',variantId:'a'}),{status:409});f.service.clear(p.id);assert.equal(activeStyle(f.store.get(p.id)).reference.path,p.visualReference.path);
});
test('HTTP styles endpoints require CSRF and preserve style previews through restart',async(t)=>{
 const f=await setup(t);await f.service.close();let runtime=createApp(f.config,{clients:{fal:f.client,lumean:{}}}),server=runtime.app.listen(0,'127.0.0.1');await new Promise((r)=>server.once('listening',r));let base=`http://127.0.0.1:${server.address().port}`,state=await(await fetch(base+'/api/state')).json();
 const send=(route,data,csrf=state.csrf)=>fetch(base+route,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(data)});
 let response=await send(`/api/projects/${f.project.id}/styles`,{scenePrompt:'A whale scene'},'bad');assert.equal(response.status,403);response=await send(`/api/projects/${f.project.id}/styles`,{scenePrompt:'A whale scene'});assert.equal(response.status,202);const {setId}=await response.json();await settle(runtime.styles);response=await send(`/api/projects/${f.project.id}/styles/select`,{setId,variantId:'a'});assert.equal(response.status,200);assert.equal((await response.json()).channelStyle.id,`${setId}:a`);
 await new Promise((r)=>server.close(r));await runtime.close();runtime=createApp(f.config,{clients:{fal:f.client,lumean:{}}});f.cleanup(()=>runtime.close());assert.equal(runtime.store.get(f.project.id).channelStyle.id,`${setId}:a`);assert.equal(f.inputs.length,3);
});
test('cancelled queued previews never submit and restart blocks an unknown first submission',async(t)=>{
 const f=await setup(t);let entered;const started=new Promise((r)=>{entered=r;});f.client.validate=async(_p,signal)=>{entered();await new Promise((resolve,reject)=>signal.addEventListener('abort',()=>reject(signal.reason),{once:true}));};f.service.create(f.project.id,{scenePrompt:'A whale scene'});await started;assert.equal(f.service.cancel(f.project.id),3);await settle(f.service);assert.equal(f.inputs.length,0);let p=f.store.get(f.project.id);assert.ok(p.styleSet.variants.every((v)=>v.imageStatus==='cancelled'));await f.service.close();
 const op=f.store.operations.list()[0];f.store.operations.put({...op,status:'creating',externalId:null});f.store.mutate(p.id,(p)=>{p.styleSet.variants[0].imageStatus='creating';return p;});const restarted=styleService(f.store,f.client,f.config);f.cleanup(()=>restarted.close());p=f.store.get(p.id);assert.equal(p.styleSet.variants[0].imageStatus,'uncertain');assert.throws(()=>restarted.create(p.id,{scenePrompt:'A whale scene'}),{status:409});assert.equal(f.inputs.length,0);
});
test('invalid received image is saved and continuing never re-submits the same paid request',async(t)=>{
 const f=await setup(t);f.client.result=async()=>Buffer.from('not an image');f.service.create(f.project.id,{scenePrompt:'A whale scene'});await settle(f.service);assert.equal(f.inputs.length,3);assert.ok(f.store.get(f.project.id).styleSet.variants.every((v)=>v.imageStatus==='error'));f.service.create(f.project.id,{scenePrompt:'A whale scene'});await settle(f.service);assert.equal(f.inputs.length,3);assert.equal(f.store.get(f.project.id).frames[0].image,null);
});
