// Remotion's CLI binds to all interfaces even with --ipv4. Its child process
// must obey this application's localhost-only requirement (document stage 35).
const http = require('node:http');
const original = http.Server.prototype.listen;
http.Server.prototype.listen = function (...args) {
  if (typeof args[0] === 'object') args[0] = {...args[0], host: '127.0.0.1'};
  else if (typeof args[1] === 'string') args[1] = '127.0.0.1';
  else args.splice(1, 0, '127.0.0.1');
  return original.apply(this, args);
};
