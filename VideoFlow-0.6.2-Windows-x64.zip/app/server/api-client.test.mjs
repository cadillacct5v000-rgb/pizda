import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import ts from 'typescript';
const compiled=ts.transpileModule(readFileSync(new URL('../src/lib/api.ts',import.meta.url),'utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;
const module=await import('data:text/javascript;base64,'+Buffer.from(compiled).toString('base64'));
const mock=(t,fn)=>{const original=globalThis.fetch;globalThis.fetch=fn;t.after(()=>{globalThis.fetch=original;});};
test('audit 10: client keeps CSRF/custom Headers and handles JSON and 204',async(t)=>{
 const calls=[];mock(t,async(url,options)=>{calls.push({url,options});return url.endsWith('/state')?Response.json({csrf:'mock-csrf'}):new Response(null,{status:204});});await module.api.state();assert.equal(await module.request('/save',{method:'POST',headers:new Headers({'X-Custom':'kept'})}),undefined);const headers=new Headers(calls[1].options.headers);assert.equal(headers.get('X-Custom'),'kept');assert.equal(headers.get('X-CSRF-Token'),'mock-csrf');
});
test('audit 10: client preserves HTTP status/request ID and distinguishes network failures',async(t)=>{
 mock(t,async()=>Response.json({message:'Конфликт',requestId:'test-request'},{status:409}));await assert.rejects(module.request('/test'),(e)=>e instanceof module.APIError&&e.status===409&&e.requestId==='test-request');globalThis.fetch=async()=>{throw new TypeError('offline');};await assert.rejects(module.request('/test'),(e)=>e instanceof module.APIError&&e.status===0);
});
test('audit 10: caller cancellation stays an AbortError and FormData keeps its boundary',async(t)=>{
 let header;mock(t,async(_url,options)=>{header=new Headers(options.headers);options.signal.throwIfAborted();return Response.json({ok:true});});const controller=new AbortController();controller.abort();await assert.rejects(module.request('/test',{signal:controller.signal}),{name:'AbortError'});await module.request('/upload',{method:'POST',body:new FormData()});assert.equal(header.has('Content-Type'),false);
});
