import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import path from 'node:path';
import {tmpdir} from 'node:os';
import {configuration} from './config.mjs';
import {providerClients} from './providers.mjs';
function fixture(t){const root=mkdtempSync(path.join(tmpdir(),'lumean-contract-'));t.after(()=>rmSync(root,{recursive:true,force:true}));return configuration({},root);}
test('safe GET retries a transient error; a billable POST is never replayed', async (t) => {
  const config=fixture(t);config.providers.lumean.key='fake';let reads=0,posts=0;
  const clients=providerClients(config,async(_url,options)=>{
    if(options.method==='POST'){posts++;throw new Error('response lost');}
    if(++reads===1)throw new Error('temporary network error');
    return Response.json({data:{config:{tts_settings:{language_code:'es'}}}});
  });
  await clients.lumean.validate({template_id:'template',language:'es'});assert.equal(reads,2);
  await assert.rejects(clients.lumean.create({template_id:'template',input_text:'Hola'}));assert.equal(posts,1);
});
test('Lumean catalog follows pagination and imports supplied alignment without exposing profile data', async(t)=>{
  const config=fixture(t);config.providers.lumean.key='fake';const routes=[];
  const clients=providerClients(config,async(url)=>{
    routes.push(url);
    if(url.includes('/templates?'))return Response.json({data:{items:[{id:url.includes('page=1&')?'one':'two',name:'Narrator',service_key:'elevenlabs',user_id:'PRIVATE',config:{tts_settings:{language_code:'es'}}}],last_page:2}});
    if(url.includes('/wallets?'))return Response.json({data:{items:[{balance_formatted:'10.50',asset:{code:'tts_units'},user:{email:'PRIVATE'}}],last_page:1}});
    return Response.json({data:{url:'https://cdn.example/alignment.json'}});
  },{download:async()=>Buffer.from(JSON.stringify({characters:['H','o','l','a',' ','m','u','n','d','o'],character_start_times_seconds:[0,.1,.2,.3,.4,.5,.6,.7,.8,.9],character_end_times_seconds:[.1,.2,.3,.4,.5,.6,.7,.8,.9,1]}))});
  const result=await clients.lumean.check();assert.equal(result.templates.length,2);assert.ok(!JSON.stringify(result).includes('PRIVATE'));assert.ok(routes.some((route)=>route.includes('page=2&')));
  const chunks=await clients.lumean.alignment({result:{service_files:['/private/order/alignment.json']}});
  assert.deepEqual(chunks,[{text:'Hola',timestamp:[0,.4]},{text:'mundo',timestamp:[.5,1]}]);
});
