import {ensure} from './core.mjs';

export function validateNarration(text, language) {
  // Language metadata never translates a prepared DOCX. Stop obvious stale
  // Russian scripts before billing instead of speaking Russian with an accent.
  if (/^(es|pt|ro)(-|$)/i.test(language)) {
    const words = text.match(/\p{L}+/gu) || [], cyrillic = words.filter((word) => /\p{Script=Cyrillic}/u.test(word));
    ensure(cyrillic.length < 3 || cyrillic.length / Math.max(1, words.length) < 0.3,
      'Язык проекта отличается от текста озвучки. Импортируйте сценарий на выбранном языке; выбор языка не переводит DOCX.', 409);
  }
}
