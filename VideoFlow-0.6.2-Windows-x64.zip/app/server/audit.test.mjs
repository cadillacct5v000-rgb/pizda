import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,readFileSync,existsSync} from 'node:fs';
import path from 'node:path';
import {tmpdir} from 'node:os';
import JSZip from 'jszip';
import {createProject,importRows,scriptRows,patchProject} from './domain.mjs';
import {buildTimeline,subtitles} from './timeline.mjs';
import {openStore} from './database.mjs';
import {atomic,within} from './core.mjs';
const project=()=>importRows(createProject(),scriptRows('This opening sentence has many more words than the final brief reply.\n\nDone.'));
test('audit 21/22: common audio fallback keeps every frame within its narration block',()=>{
 const p=project();p.frames.forEach((f)=>f.image={path:'image.png'});p.uploads.project={path:'own.mp3',duration:12};const timeline=buildTimeline(p),first=timeline.visuals[0],second=timeline.visuals[1];const secondCue=timeline.cues.find((cue)=>cue.text==='Done.');assert.equal(first.durationInFrames/timeline.fps,secondCue.start);assert.equal(second.from/timeline.fps,secondCue.start);
});
test('audit 31/32: long narration is paginated without dropping caption words',()=>{
 const text=Array.from({length:100},(_,i)=>`palabra${i}`).join(' '),p=importRows(createProject(),scriptRows(text));p.frames[0].image={path:'image.png'};p.blocks[0].audio={path:'audio.mp3',duration:40};const timeline=buildTimeline(p);assert.ok(timeline.cues.length>1);assert.equal(timeline.cues.map((c)=>c.text).join(' ').replace(/\s+/g,' '),text);assert.ok(timeline.cues.every((c)=>c.text.split('\n').length<=p.captionStyle.maxLines));assert.ok(subtitles(timeline.cues).includes('palabra99'));
});
test('audit 11/13: a leftover manifest cannot resurrect a deleted SQLite project',()=>{
 const root=mkdtempSync(path.join(tmpdir(),'flow-audit-delete-'));let store;
 try{store=openStore(root);const saved=store.put(project(),null),file=within(store.projectsDir,`${saved.id}/manifest.json`),manifest=readFileSync(file);store.delete(saved.id);atomic(file,manifest);store.close();store=openStore(root);assert.equal(store.list().length,0);}finally{store?.close();rmSync(root,{recursive:true,force:true});}
});
test('audit 13: malformed item patches are user errors, never TypeErrors',()=>{
 assert.throws(()=>patchProject(project(),{blocks:[null]}),{status:400});
});
test('audit 15: malformed XML and equivalent padded shot IDs are diagnosed',async()=>{
 const {parseDocx}=await import('./docx.mjs');
 const doc=async(xml)=>{const z=new JSZip();z.file('word/document.xml',xml);return z.generateAsync({type:'nodebuffer'});};
 await assert.rejects(parseDocx(await doc('<w:document><w:body><w:tbl></w:document>')),{status:400});
 const xml='<w:document xmlns:w="w"><w:body><w:tbl>'+['S01.01','S001.001'].map((id)=>`<w:tr><w:tc><w:p><w:r><w:t>${id}</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>Texto</w:t></w:r></w:p></w:tc></w:tr>`).join('')+'</w:tbl></w:body></w:document>';
 await assert.rejects(parseDocx(await doc(xml)),/повтор/);
});
test('audit 15/20: leading visual-only shots share narration, silent scenes do not require paid TTS',()=>{
 const p=importRows(createProject(),[
  {shotId:'S01.01',sceneKey:'1',narration:'',visual:'Opening'},
  {shotId:'S01.02',sceneKey:'1',narration:'Hola, océano.',visual:'Water'},
  {shotId:'S02.01',sceneKey:'2',narration:'',visual:'Quiet transition'},
  {shotId:'S03.01',sceneKey:'3',narration:'Otra escena.',visual:'Whale'},
 ]);
 assert.equal(p.frames[0].blockId,p.frames[1].blockId);assert.equal(p.scenes[1].voiceoverSkipped,true);p.frames.forEach((f)=>f.image={path:'image.png'});p.blocks.filter((b)=>b.text).forEach((b)=>b.audio={path:'audio.mp3',duration:2});const timeline=buildTimeline(p);assert.equal(timeline.audio.length,2);assert.equal(timeline.durationInFrames,240);
});
test('audit 21/31: caption pagination preserves Unicode and respects block frame minimums',async()=>{
 const {allocateFrames,captionPages}=await import('./timeline.mjs');assert.deepEqual(allocateFrames(30,[100,1],[1,20]),[10,20]);
 const text='Océano 🐋🌊 '.repeat(30).trim(),pages=captionPages([{start:0,end:40,text}],{fontSize:100,safeArea:300,maxLines:1});assert.equal(pages.map((c)=>c.text).join('').replace(/\s/g,''),text.replace(/\s/g,''));assert.ok(pages.every((c)=>c.text.split('\n').length<=1));assert.ok(!subtitles(pages).includes('\ufffd'));
});
test('audit 11: first legacy import is atomic and only runs once',()=>{
 const root=mkdtempSync(path.join(tmpdir(),'flow-audit-legacy-'));let store;
 try{const p=project();atomic(within(root,`projects/${p.id}/manifest.json`),JSON.stringify(p));store=openStore(root);assert.equal(store.list().length,1);assert.ok(store.db.prepare('SELECT 1 FROM schema_migrations WHERE version=2').get());store.close();store=openStore(root);assert.equal(store.list().length,1);}finally{store?.close();rmSync(root,{recursive:true,force:true});}
});
test('audit 21/28: native process cancellation settles after owned child has closed',async(t)=>{
 const {processFile}=await import('./media.mjs'),{setTimeout:pause}=await import('node:timers/promises');const root=mkdtempSync(path.join(tmpdir(),'flow-audit-process-')),ready=path.join(root,'ready');let pid;
 t.after(()=>{if(pid){try{process.kill(pid);}catch(error){if(error.code!=='ESRCH')throw error;}}rmSync(root,{recursive:true,force:true});});
 const controller=new AbortController(),script=`const fs=require('node:fs');process.on('SIGTERM',()=>setTimeout(()=>process.exit(0),100));fs.writeFileSync(${JSON.stringify(ready)},String(process.pid));setInterval(()=>{},1000);`;
 const pending=processFile(process.execPath,['-e',script],{signal:controller.signal});const rejected=assert.rejects(pending,{name:'AbortError'});
 for(let i=0;i<100&&!existsSync(ready);i++)await pause(10);assert.ok(existsSync(ready));pid=Number(readFileSync(ready,'utf8'));controller.abort();await rejected;assert.throws(()=>process.kill(pid,0),{code:'ESRCH'});pid=null;
});
test('audit 12/13: locked directory leaves project intact; deferred cleanup cannot resurrect it',()=>{
 const root=mkdtempSync(path.join(tmpdir(),'flow-audit-trash-'));let store;
 try{store=openStore(root,{renameProject:()=>{throw Object.assign(Error('locked'),{code:'EPERM'});}});const p=store.put(project(),null);assert.throws(()=>store.delete(p.id),{status:409});assert.equal(store.get(p.id).id,p.id);store.close();store=openStore(root,{removeDeleted:()=>{throw Object.assign(Error('locked'),{code:'EPERM'});}});store.delete(p.id);assert.equal(store.list().length,0);assert.equal(existsSync(within(store.projectsDir,p.id)),false);assert.equal(store.cleanupStatus().pending,1);store.close();store=openStore(root);assert.equal(store.list().length,0);assert.equal(store.cleanupStatus().pending,0);}finally{store?.close();rmSync(root,{recursive:true,force:true});}
});
test('audit 12/13: failed database deletion restores the staged media directory',()=>{
 const root=mkdtempSync(path.join(tmpdir(),'flow-audit-delete-rollback-'));let store,other;
 try{store=openStore(root);const p=store.put(project(),null);other=openStore(root);other.db.exec('BEGIN IMMEDIATE');store.db.pragma('busy_timeout=1');assert.throws(()=>store.delete(p.id));assert.equal(store.get(p.id).id,p.id);assert.ok(existsSync(within(store.projectsDir,`${p.id}/manifest.json`)));other.db.exec('ROLLBACK');}finally{other?.close();store?.close();rmSync(root,{recursive:true,force:true});}
});
test('audit 07: next stage is deterministic across optional voice/animation/captions',async()=>{
 const {nextStage}=await import('./domain.mjs');const p=project();assert.equal(nextStage(p),'voiceover');p.options.voiceoverSkipped=true;assert.equal(nextStage(p),'storyboard');p.frames.forEach((f)=>f.approved=true);assert.equal(nextStage(p),'images');p.frames.forEach((f)=>f.image={path:'image.png'});assert.equal(nextStage(p),'subtitles');p.options.animationEnabled=true;assert.equal(nextStage(p),'animation');p.frames.forEach((f)=>f.video={path:'clip.mp4'});p.options.subtitlesEnabled=false;assert.equal(nextStage(p),'assembly');
});
test('audit 25/29: changing a prompt cannot enqueue a second paid task for an active frame',async()=>{
 const {generationService}=await import('./generation.mjs'),{configuration}=await import('./config.mjs'),{setTimeout:pause}=await import('node:timers/promises');const root=mkdtempSync(path.join(tmpdir(),'flow-audit-double-')),store=openStore(root),config=configuration({DATA_DIR:root},root);config.providers.fal.key='mock';let service,release,started;
 try{const p=project();p.frames[0].approved=true;p.frames[0].imagePrompt='Original whale';const saved=store.put(p,null);const gate=new Promise((r)=>release=r),entered=new Promise((r)=>started=r);service=generationService(store,{fal:{validate:async()=>{started();await gate;},create:async()=>{throw Error('Must not send changed data');}}},config);service.enqueue(saved.id,'image',saved.frames[0].id);await entered;store.mutate(saved.id,(p)=>patchProject(p,{frames:[{id:p.frames[0].id,imagePrompt:'Changed whale',approved:true}]}));assert.throws(()=>service.enqueue(saved.id,'image',saved.frames[0].id),{status:409});release();for(let i=0;i<100&&service.stats().some((q)=>q.keys.length);i++)await pause(5);}finally{release?.();await service?.close();store.close();rmSync(root,{recursive:true,force:true});}
});
test('audit 21/28: cancellation has a hard deadline even if a child ignores SIGTERM',{timeout:5000},async(t)=>{
 const {processFile}=await import('./media.mjs'),{setTimeout:pause}=await import('node:timers/promises');const root=mkdtempSync(path.join(tmpdir(),'flow-audit-force-')),ready=path.join(root,'ready');let pid;
 t.after(()=>{if(pid){try{process.kill(pid,'SIGKILL');}catch(error){if(error.code!=='ESRCH')throw error;}}rmSync(root,{recursive:true,force:true});});
 const controller=new AbortController(),script=`const fs=require('node:fs');process.on('SIGTERM',()=>{});fs.writeFileSync(${JSON.stringify(ready)},String(process.pid));setInterval(()=>{},1000);`,pending=processFile(process.execPath,['-e',script],{signal:controller.signal});const rejected=assert.rejects(pending,{name:'AbortError'});
 for(let i=0;i<100&&!existsSync(ready);i++)await pause(10);assert.ok(existsSync(ready));pid=Number(readFileSync(ready,'utf8'));controller.abort();await rejected;assert.throws(()=>process.kill(pid,0),{code:'ESRCH'});pid=null;
});
test('audit 16: imported manual blocks must fit the editor limits',()=>{
 assert.throws(()=>scriptRows('x'.repeat(20001)),{status:400});assert.equal(scriptRows('x'.repeat(20000)).length,1);
});
test('audit 31: exported captions escape markup without deleting comparison symbols',()=>{
 const result=subtitles([{start:0,end:2,text:'A < B & C > D'}]);assert.ok(result.includes('A &lt; B &amp; C &gt; D'));
});
test('audit 18/30: provider cost strings cannot concatenate or hide charges as refunded',async()=>{
 const {creditCost}=await import('./generation.mjs');assert.deepEqual(creditCost({credits:'1.25',refunded:'false'}),{unit:'credits',value:1.25,refunded:null});assert.equal(creditCost({credits:0}).value,0);for(const value of [null,'',true,'free','Infinity',-1,Infinity])assert.equal(creditCost({credits:value}).value,null);
});
test('audit 09/33: shutdown during Studio startup cannot spawn a late child',async()=>{
 const {renderService}=await import('./render.mjs'),{readdirSync}=await import('node:fs');const root=mkdtempSync(path.join(tmpdir(),'flow-audit-studio-')),store=openStore(root),renderer=renderService(store);
 try{const p=project();p.options.voiceoverSkipped=true;p.frames.forEach((f)=>{f.image={path:`${p.id}/images/${f.id}.png`};atomic(within(store.projectsDir,f.image.path),'fixture');});const opening=renderer.openStudio(p),rejected=assert.rejects(opening,{name:'AbortError'});await renderer.close();await rejected;assert.ok(!readdirSync(root).some((name)=>name.startsWith('studio-')));}finally{await renderer.close();store.close();rmSync(root,{recursive:true,force:true});}
});
