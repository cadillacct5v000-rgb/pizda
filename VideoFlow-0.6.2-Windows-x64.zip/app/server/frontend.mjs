import {readFileSync} from 'node:fs';
import path from 'node:path';
import {hash,within} from './core.mjs';
import {VERSION} from './version.mjs';
export function frontendStatus(directory, expectedVersion=VERSION) {
  try {
    const build=JSON.parse(readFileSync(path.join(directory,'build.json'),'utf8'));
    if(build.version!==expectedVersion)return {ready:false,error:'Версия интерфейса отличается от сервера. Повторите установку или обновление.'};
    if(!build.files?.['index.html']||!Object.keys(build.files).some((name)=>/^assets\/.*\.js$/.test(name)))return {ready:false,error:'В сборке интерфейса отсутствуют обязательные файлы.'};
    for(const [name,digest]of Object.entries(build.files))if(hash(readFileSync(within(directory,name)).toString('base64'))!==digest)return {ready:false,error:'Файлы интерфейса повреждены. Повторите установку.'};
    return {ready:true,version:build.version};
  }catch{return {ready:false,error:'Интерфейс не собран. Запустите Install Video AI Auto.bat и дождитесь завершения установки.'};}
}
