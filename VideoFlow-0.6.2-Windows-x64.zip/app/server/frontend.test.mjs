import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,writeFileSync} from 'node:fs';
import path from 'node:path';
import {tmpdir} from 'node:os';
import {frontendStatus} from './frontend.mjs';
import {atomic,hash} from './core.mjs';
import {VERSION} from './version.mjs';
import {configuration} from './config.mjs';
import {createApp} from './app.mjs';
function fixture(){const root=mkdtempSync(path.join(tmpdir(),'flow-frontend-')),dist=path.join(root,'dist');const files={'index.html':'<html><div id="root"></div><script src="/assets/app.js"></script></html>','assets/app.js':'console.log("frontend")'};for(const [name,data]of Object.entries(files))atomic(path.join(dist,name),data);atomic(path.join(dist,'build.json'),JSON.stringify({version:VERSION,files:Object.fromEntries(Object.entries(files).map(([name,data])=>[name,hash(Buffer.from(data).toString('base64'))]))}));return {root,dist};}
test('frontend gate rejects absent, stale and damaged builds before reporting ready',(t)=>{
 const {root,dist}=fixture();t.after(()=>rmSync(root,{recursive:true,force:true}));assert.equal(frontendStatus(dist).ready,true);assert.equal(frontendStatus(path.join(root,'missing')).ready,false);assert.equal(frontendStatus(dist,'0.0.0').ready,false);writeFileSync(path.join(dist,'assets/app.js'),'damaged');assert.equal(frontendStatus(dist).ready,false);
});
test('missing frontend returns a useful 503 and health reports false; ready frontend serves root and deep route',async()=>{
 for(const ready of [false,true]){
  const {root,dist}=fixture(),config=configuration({DATA_DIR:path.join(root,'data')},root),runtime=createApp(config,{frontendDir:ready?dist:path.join(root,'missing')});const server=runtime.app.listen(0,'127.0.0.1');await new Promise((r)=>server.once('listening',r));
  try{const base=`http://127.0.0.1:${server.address().port}`,health=await(await fetch(base+'/api/health')).json();assert.equal(health.frontend.ready,ready);for(const route of ['/','/projects/test/draft']){const response=await fetch(base+route),body=await response.text();assert.equal(response.status,ready?200:503);assert.match(body,ready?/id="root"/:/Install Video AI Auto/);assert.ok(!body.includes('Cannot GET'));}}
  finally{await new Promise((r)=>server.close(r));await runtime.close();rmSync(root,{recursive:true,force:true});}
 }
});
