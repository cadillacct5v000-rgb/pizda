import path from 'node:path';
import {mkdtemp, mkdir, copyFile, rm, rename} from 'node:fs/promises';
import {existsSync, statSync} from 'node:fs';
import {spawn} from 'node:child_process';
import {bundle} from '@remotion/bundler';
import {renderMedia, selectComposition, makeCancelSignal} from '@remotion/renderer';
import {appDir} from './config.mjs';
import {within, ensure, atomic, hash, now} from './core.mjs';
import {buildTimeline} from './timeline.mjs';
import {probe,normalizeClip} from './media.mjs';
import {setTimeout as pause} from 'node:timers/promises';
import net from 'node:net';
import {VERSION} from './version.mjs';

export function renderService(store, {browserExecutable} = {}) {
  let studio, studioDirectory, studioHash, studioURL, studioOpening = false, studioPreparing, studioPreparation, studioEpoch=0, studioClosing;
  async function copyAsset(entry,publicDir,fps,signal) {
    signal?.throwIfAborted();
    const source=within(store.projectsDir,entry.path);ensure(existsSync(source),'Отсутствует файл проекта',409);
    const filename=`${hash({path:entry.path,kind:entry.kind,duration:entry.durationInFrames,fps})}${path.extname(entry.path)}`;
    if(entry.kind==='video'&&Number.isFinite(entry.normalizedDuration)&&Math.abs(entry.normalizedDuration-entry.durationInFrames/fps)>1/fps)await normalizeClip(source,path.join(publicDir,filename),entry.durationInFrames/fps,signal,fps);
    else await copyFile(source,path.join(publicDir,filename));
    signal?.throwIfAborted();return filename;
  }
  async function prepare(project,signal) {
    const timeline = buildTimeline(project), workspace = await mkdtemp(path.join(store.root, 'studio-'));
    try {
      const publicDir = path.join(workspace, 'public'); await mkdir(publicDir);
      for (const entry of [...timeline.visuals, ...timeline.audio]) {
        entry.path=await copyAsset(entry,publicDir,timeline.fps,signal);
      }
      const props = path.join(workspace, 'props.json'); atomic(props, JSON.stringify({timeline}));
      return {workspace, publicDir, props};
    } catch (error) {await rm(workspace, {recursive: true, force: true}); throw error;}
  }
  function close() {
    studioEpoch++;
    studioPreparing?.abort(new DOMException('Studio остановлена','AbortError'));
    if(studioClosing)return studioClosing;
    studioClosing=(async()=>{
    if(studioPreparation)await Promise.allSettled([studioPreparation]);
    const current = studio; studio = null;
    if (current && current.exitCode === null && !current.killed) {
      await new Promise((resolve) => {const timer = setTimeout(() => {current.kill('SIGKILL');}, 5000); current.once('exit', () => {clearTimeout(timer); resolve();}); current.kill();});
    }
    if (studioDirectory) await rm(studioDirectory, {recursive: true, force: true});
    studioDirectory = null; studioHash = null;
    })().finally(()=>{studioClosing=null;});
    return studioClosing;
  }
  async function render(project, signal, onProgress = () => {}) {
    const timeline = buildTimeline(project), workspace = await mkdtemp(path.join(store.root, 'render-'));
    const fingerprint = hash(timeline), publicDir = path.join(workspace, 'public');
    const final = within(store.projectsDir, `${project.id}/renders/${fingerprint.slice(0, 16)}.mp4`), temporary = `${final}.tmp.mp4`;
    try {
      await mkdir(publicDir);
      const mapping = new Map();
      for (const entry of [...timeline.visuals, ...timeline.audio]) {
        const identity=JSON.stringify({path:entry.path,kind:entry.kind,duration:entry.durationInFrames,fps:timeline.fps});
        if(!mapping.has(identity))mapping.set(identity,await copyAsset(entry,publicDir,timeline.fps,signal));
        entry.path=mapping.get(identity);
      }
      signal.throwIfAborted();
      const serveUrl = await bundle({entryPoint: path.join(appDir, 'remotion/index.tsx'), publicDir, enableCaching: true});
      const inputProps = {timeline};
      const composition = await selectComposition({serveUrl, id: 'FinalVideo', inputProps, browserExecutable});
      const cancel = makeCancelSignal(), abort = () => cancel.cancel(); signal.addEventListener('abort', abort, {once: true});
      try {
        signal.throwIfAborted(); await mkdir(path.dirname(final), {recursive: true});
        await renderMedia({composition, serveUrl, codec: 'h264', audioCodec: 'aac', enforceAudioTrack: true, outputLocation: temporary, inputProps, pixelFormat: 'yuv420p', browserExecutable, cancelSignal: cancel.cancelSignal, concurrency: 2, onProgress: ({progress}) => onProgress(progress)});
      } finally { signal.removeEventListener('abort', abort); }
      signal.throwIfAborted();
      const info = await probe(temporary, signal), video = info.streams.find((stream) => stream.codec_type === 'video'), audio = info.streams.find((stream) => stream.codec_type === 'audio');
      ensure(video?.codec_name === 'h264' && video.width === 1920 && video.height === 1080 && video.r_frame_rate === `${timeline.fps}/1` && audio?.codec_name === 'aac' && Math.abs(info.duration - timeline.durationInFrames / timeline.fps) <= 0.12 && statSync(temporary).size > 1000, 'Результат рендера не прошёл проверку', 422);
      await rename(temporary, final);
      const manifest = {version: VERSION, projectId: project.id, revision: project.revision, createdAt: now(), inputHash: fingerprint, timeline: buildTimeline(project), duration: info.duration, codecs: ['h264','aac']};
      atomic(`${final}.json`, JSON.stringify(manifest, null, 2));
      return {path: path.relative(store.projectsDir, final).split(path.sep).join('/'), duration: info.duration, inputHash: fingerprint, createdAt: now(), manifestPath: path.relative(store.projectsDir, `${final}.json`).split(path.sep).join('/')};
    } finally { await rm(workspace, {recursive: true, force: true}); await rm(temporary, {force: true}); }
  }
  return {render,
    async openStudio(project) {
      ensure(!studioOpening, 'Studio уже запускается', 409); studioOpening = true;
      try {
      const inputHash = hash(buildTimeline(project));
      if (studio && studioHash === inputHash) return studioURL;
      const epoch=studioEpoch+1;await close();if(studioEpoch!==epoch)throw new DOMException('Studio остановлена','AbortError');studioPreparing=new AbortController();const controller=studioPreparing;studioPreparation=prepare(project,controller.signal);const prepared=await studioPreparation;studioDirectory=prepared.workspace;controller.signal.throwIfAborted();
      const port = await new Promise((resolve, reject) => {const socket = net.createServer(); socket.once('error', reject); socket.listen(0, '127.0.0.1', () => {const assigned = socket.address().port; socket.close(() => resolve(assigned));});});
      const current = spawn(process.execPath, ['--require', path.join(appDir, 'server/studio-local.cjs'), path.join(appDir, 'node_modules/@remotion/cli/remotion-cli.js'), 'studio', 'remotion/index.tsx', `--port=${port}`, '--no-open', `--props=${prepared.props}`, `--public-dir=${prepared.publicDir}`], {cwd: appDir, windowsHide: true, stdio: 'ignore'});
      studio = current; studioHash = inputHash; studioURL = `http://127.0.0.1:${port}`;
      current.once('error', () => {if (studio === current) studio = null;}); current.once('exit', () => {if (studio === current) studio = null;});
      for (let attempt = 0; attempt < 100; attempt++) {
        controller.signal.throwIfAborted();
        if (!studio) {studioPreparation=null;await close(); throw new Error('Remotion Studio не запустился');}
        try {const response = await fetch(studioURL, {signal: AbortSignal.any([controller.signal,AbortSignal.timeout(500)])}); if (response.ok) {controller.signal.throwIfAborted();return studioURL;}} catch (error) {if(controller.signal.aborted)throw error; /* The local child is still starting. */ }
        await pause(250,undefined,{signal:controller.signal});
      }
      studioPreparation=null;await close(); throw new Error('Remotion Studio не ответил вовремя');
      } finally {studioOpening = false;studioPreparing=null;studioPreparation=null;}
    },
    close,
  };
}
