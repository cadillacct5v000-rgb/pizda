import {parentPort, workerData} from 'node:worker_threads';

let recognizer;
parentPort.on('message', async ({audio}) => {
  try {
    if (!recognizer) {
      const {pipeline, env} = await import('@huggingface/transformers');
      env.cacheDir = workerData.cache;
      recognizer = await pipeline('automatic-speech-recognition', workerData.model, {device: 'cpu', dtype: 'q8'});
    }
    const result = await recognizer(audio, {return_timestamps: 'word', chunk_length_s: 30, stride_length_s: 5});
    parentPort.postMessage({chunks: result.chunks || []});
  } catch { parentPort.postMessage({error: 'Локальный Whisper не смог загрузить модель или распознать аудио. Проверьте доступ к модели и повторите выравнивание.'}); }
});
