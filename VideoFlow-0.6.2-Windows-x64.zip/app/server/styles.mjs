import {readFileSync,renameSync,rmSync} from 'node:fs';
import {ensure,hash,id,now,atomic,within,redact} from './core.mjs';
import {createGenerationQueue} from './queue.mjs';
import {poll} from './providers.mjs';
import {validateMedia,normalizeImage,normalizeClip} from './media.mjs';

export const styleDirections = [
  {id:'a',label:'Вариант 1 · палитра и свет',instruction:'Keep the reference visual medium, level of detail, character anatomy and overall mood. Develop a distinct cohesive palette with improved contrast and lighting. Preserve the reference drawing or rendering method; do not turn it into another medium. Make a new art direction rather than reproducing its exact composition, logos or embedded text.'},
  {id:'b',label:'Вариант 2 · формы и композиция',instruction:'Keep the reference visual medium, atmosphere and subject identity. Develop distinctive shape language, silhouettes, framing and visual hierarchy, while retaining the original level of detail and the qualities that make it readable. Adapt linework only if the reference uses lines; do not impose outlines on photographs or 3D renders. Create an original composition without copying logos or text.'},
  {id:'c',label:'Вариант 3 · фактура и глубина',instruction:'Keep the reference visual medium and recognizable character design. Develop an original treatment of textures, materials, shading and depth suited to that medium, with a cohesive palette. Preserve flatness if it is fundamental to the reference; do not impose photorealism, pencil drawing or 3D. Make an original image without reference logos or embedded text.'},
];
export function activeStyle(project) {
  return project.channelStyle ? {reference:project.channelStyle.reference,instruction:project.channelStyle.instruction} : {reference:project.visualReference,instruction:''};
}
export function styleService(store,client,config) {
  const queue=createGenerationQueue({name:'styles',limit:1});
  for(const op of store.operations.list())if(op.stage?.startsWith('style-')&&['creating','running','queued'].includes(op.status))store.operations.put({...op,status:op.status==='creating'&&!op.externalId?'uncertain':'paused'});
  for(const p of store.list())if(p.styleSet){let changed=false;for(const v of p.styleSet.variants)for(const field of ['image','video'])if(['queued','creating','running'].includes(v[`${field}Status`])){const op=store.operations.list().find((op)=>op.projectId===p.id&&op.stage===`style-${field}`&&op.itemId===v.id&&op.key.includes(p.styleSet.id));v[`${field}Status`]=op?.status==='uncertain'?'uncertain':'paused';changed=true;}if(changed)store.put(p,p.revision);}

  const update=(projectId,setId,variantId,patch)=>store.mutate(projectId,(p)=>{if(p.styleSet?.id===setId){const v=p.styleSet.variants.find((v)=>v.id===variantId);if(v)Object.assign(v,patch);}return p;});
  function enqueue(projectId,setId,variantId,stage,{newTake=false,acknowledgeUncertain=false}={}) {
    const project=store.get(projectId),set=project.styleSet;
    ensure(set?.id===setId,'Тройка стилей изменилась',409);
    const variant=set.variants.find((v)=>v.id===variantId);ensure(variant,'Вариант не найден',404);
    const video=stage==='video', field=video?'video':'image',statusField=`${field}Status`, model=video?project.models.falVideoModel:set.model;
    ensure(!video || variant.image,'Сначала дождитесь изображения варианта',409);
    if(variant[field]&&!newTake&&(!video||variant.videoModel===model))return;
    const payload=video?{stage:'video',model,prompt:'Subtle natural motion appropriate to this scene. Preserve the original illustration or rendering style, character identity and composition. One continuous shot. No new text. Camera: slow gentle movement.',image:readFileSync(within(store.projectsDir,variant.image.path)).toString('base64'),duration:5}:{stage:'image',model,prompt:`${set.scenePrompt}\nArt direction: ${variant.instruction}`,reference:readFileSync(within(store.projectsDir,set.source.path)).toString('base64')};
    const fingerprint=hash(payload),key=`${projectId}:style-${field}:${setId}:${variantId}:${fingerprint}`;
    if(queue.stats().keys.includes(key))return;
    let op=store.operations.get(key);
    if(op?.status==='uncertain')ensure(newTake&&acknowledgeUncertain,'Отправка могла быть оплачена. Проверьте fal.ai и подтвердите повтор.',409);
    if(!op||newTake)op={key,projectId,stage:`style-${field}`,itemId:variantId,provider:'fal',status:'queued',externalId:null,attempt:id(),createdAt:now()};
    op.status='queued';op.error=null;store.operations.put(op);update(projectId,setId,variantId,{[statusField]:'queued',error:null});
    queue.enqueue(key,async(signal)=>{
      const status=(value)=>{op.status=value;store.operations.put(op);update(projectId,setId,variantId,{[statusField]:value,error:null});};
      const current=()=>ensure(store.get(projectId).styleSet?.id===setId,'Тройка стилей изменилась. Полученные файлы сохраняются, но не применяются.',409);
      const chargeId=`${key}:${op.attempt}`;
      let temporary;
      try {
        current();let bytes;
        if(op.receiptPath)bytes=readFileSync(within(config.root,op.receiptPath));
        else {
          if(!op.externalId){
            await client.validate(payload,signal);const prepared=await client.prepare(payload,signal);signal.throwIfAborted();current();
            status('creating');store.mutate(projectId,(p)=>{if(!p.cost.some((c)=>c.id===chargeId))p.cost.push({id:chargeId,stage:`style-${field}`,provider:'fal',unit:null,value:null});return p;});
            const accepted=await client.create(prepared,signal,(externalId)=>{op.externalId=externalId;store.operations.put(op);});ensure(accepted.id,'fal.ai не вернул ID превью',502);op.externalId=accepted.id;
          }
          status('running');const result=await poll(client,op.externalId,config,signal);bytes=await client.result(result,field,signal);
          op.receiptPath=`style-results/${projectId}/${op.attempt}.media`;atomic(within(config.root,op.receiptPath),bytes);store.operations.put(op);
        }
        signal.throwIfAborted();const relative=`${projectId}/${video?'clips':'images'}/style-${setId}-${variantId}-${op.attempt}.${video?'mp4':'png'}`,target=within(store.projectsDir,relative);temporary=`${target}.upload`;
        atomic(temporary,bytes);await validateMedia(temporary,video?'video':'image',signal);
        if(video)await normalizeClip(temporary,`${temporary}.mp4`,5,signal,30);else await normalizeImage(temporary,`${temporary}.png`,signal);
        renameSync(`${temporary}.${video?'mp4':'png'}`,target);current();signal.throwIfAborted();
        const asset={path:relative,duration:video?5:null,provider:'fal',externalId:op.externalId,createdAt:now()};
        update(projectId,setId,variantId,{[field]:asset,[statusField]:'ready',error:null,...(video?{videoModel:model}:{})});op.status='ready';op.error=null;store.operations.put(op);
      }catch(error){
        const rejected=op.status==='creating'&&!op.externalId&&[400,401,402,403,404,413,415,422,429].includes(error.details?.providerStatus);
        op.status=op.status==='creating'&&!op.externalId&&!rejected?'uncertain':signal.aborted?'cancelled':'error';op.error=redact(error.message,[config.providers.fal.key]);store.operations.put(op);
        if(rejected)store.mutate(projectId,(p)=>{p.cost=p.cost.filter((c)=>c.id!==chargeId);return p;});
        if(signal.aborted&&op.externalId){try{await client.cancel(op.externalId);}catch{op.cancelUnconfirmed=true;store.operations.put(op);}}
        update(projectId,setId,variantId,{[statusField]:op.status,error:op.status==='uncertain'?'Результат отправки неизвестен. Автоматического платного повтора нет.':op.error});throw error;
      }finally{if(temporary)for(const suffix of ['', '.png','.mp4'])rmSync(temporary+suffix,{force:true});}
    });
  }
  function create(projectId,{scenePrompt,newSet=false}={}) {
    let p=store.get(projectId);ensure(config.providers.fal.key,'Введите ключ fal.ai',409);ensure(p.visualReference,'Загрузите исходный образец стиля',409);
    ensure(['fal-ai/nano-banana-2','fal-ai/nano-banana-pro'].includes(p.models.falImageModel),'Для вариантов стиля выберите Nano Banana 2 или Pro',409);
    scenePrompt=(scenePrompt||p.frames[0]?.imagePrompt||'An original scene inspired by the reference subject and visual medium.').trim();ensure(scenePrompt.length>=3&&scenePrompt.length<=10000,'Описание тестовой сцены: от 3 до 10000 символов',400);
    const fingerprint=hash({source:p.visualReference,model:p.models.falImageModel,scenePrompt,version:1});
    ensure(!queue.stats().keys.some((k)=>k.startsWith(`${projectId}:`)),'Дождитесь завершения текущих превью или остановите их',409);
    if(newSet||p.styleSet?.fingerprint!==fingerprint){p=store.mutate(projectId,(latest)=>{latest.styleSet={id:id(),fingerprint,source:structuredClone(p.visualReference),model:p.models.falImageModel,scenePrompt,createdAt:now(),variants:styleDirections.map((v)=>({...v,image:null,video:null,imageStatus:'draft',videoStatus:'draft'}))};return latest;});}
    // Check every unknown outcome before queuing any additional billable requests.
    ensure(!p.styleSet.variants.some((v)=>v.imageStatus==='uncertain'),'Есть превью с неизвестным исходом. Проверьте fal.ai и подтвердите повтор отдельно.',409);
    for(const v of p.styleSet.variants)enqueue(projectId,p.styleSet.id,v.id,'image');
    return {setId:p.styleSet.id};
  }
  function videos(projectId) {const p=store.get(projectId);ensure(p.styleSet?.variants.every((v)=>v.image),'Дождитесь всех трёх изображений',409);ensure(!p.styleSet.variants.some((v)=>v.videoStatus==='uncertain'),'Подтвердите повтор неизвестной отправки отдельно',409);for(const v of p.styleSet.variants)enqueue(projectId,p.styleSet.id,v.id,'video');return {setId:p.styleSet.id};}
  function select(projectId,{setId,variantId}) {const p=store.get(projectId);ensure(p.styleSet?.id===setId,'Эта тройка устарела',409);const variant=p.styleSet.variants.find((v)=>v.id===variantId);ensure(variant?.image&&variant.imageStatus==='ready','Вариант ещё не готов',409);return store.mutate(projectId,(latest)=>{latest.channelStyle={id:`${setId}:${variantId}`,label:variant.label,instruction:variant.instruction,reference:structuredClone(variant.image)};return latest;});}
  return {create,videos,select,retry(projectId,{setId,variantId,stage='image',acknowledgeUncertain=false}){ensure(['image','video'].includes(stage),'Неверный этап');enqueue(projectId,setId,variantId,stage,{newTake:true,acknowledgeUncertain});return {queued:true};},
    clear(projectId){return store.mutate(projectId,(p)=>{delete p.channelStyle;return p;});},
    cancel(projectId){let count=0;for(const key of queue.stats().keys)if(key.startsWith(`${projectId}:`)&&queue.cancel(key)){count++;const op=store.operations.get(key);if(op?.status==='queued'){op.status='cancelled';store.operations.put(op);const match=key.split(':');update(projectId,match[2],match[3],{[op.stage==='style-video'?'videoStatus':'imageStatus']:'cancelled'});}}return count;},
    stats:()=>queue.stats(),close:()=>queue.close(),
  };
}
