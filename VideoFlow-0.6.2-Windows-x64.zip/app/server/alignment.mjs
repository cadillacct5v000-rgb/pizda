import {ensure} from './core.mjs';
import {pcm} from './media.mjs';
import path from 'node:path';
import {Worker} from 'node:worker_threads';

export function tokens(value) { return value.normalize('NFKC').toLocaleLowerCase().match(/[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}]|[\p{L}\p{N}]+/gu) || []; }
export function alignBlocks(blocks, chunks, duration) {
  ensure(Number.isFinite(duration) && duration > 0, 'Неверная длительность');
  const spoken = chunks.flatMap((chunk) => {
    const words = tokens(chunk.text), [start, end] = chunk.timestamp || [];
    if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) return [];
    return words.map((word, index) => ({word, start: start + (end - start) * index / words.length, end: start + (end - start) * (index + 1) / words.length}));
  }).filter((entry) => entry.start >= 0 && entry.end <= duration + 0.05);
  let cursor = 0, boundary = 0;
  return blocks.map((block) => {
    const expected = tokens(block.text), matches = [];
    // Limited forward search preserves order and avoids quadratic memory on long scripts.
    for (const word of expected) {
      let position = -1;
      for (let candidate = cursor; candidate < Math.min(spoken.length, cursor + 40); candidate++) if (spoken[candidate].word === word) { position = candidate; break; }
      if (position >= 0) { matches.push(spoken[position]); cursor = position + 1; }
    }
    const start = Math.max(boundary, matches[0]?.start ?? boundary), end = Math.min(duration, Math.max(start, matches.at(-1)?.end ?? start)); boundary = end;
    return {blockId: block.id, start, end, confidence: expected.length ? matches.length / expected.length : 0};
  });
}
export function transcriber(config, implementation, {workerFactory = (url, options) => new Worker(url, options)} = {}) {
  let worker, pending = false;
  const run = async (file, blocks, duration, signal) => {
    ensure(!pending, 'Whisper уже обрабатывает аудио', 409); pending = true;
    const deadline = AbortSignal.timeout(config.whisperTimeout || 900000), combined = AbortSignal.any([signal, deadline]);
    try {
      combined.throwIfAborted();
      const audio = await pcm(file, `${file}.whisper.tmp`, combined); combined.throwIfAborted();
      const result = implementation ? await implementation(audio, {return_timestamps: 'word', chunk_length_s: 30, stride_length_s: 5}) : await new Promise((resolve, reject) => {
        if (!worker) {
          worker = workerFactory(new URL('./whisper-worker.mjs', import.meta.url), {workerData: {model: config.whisperModel, cache: path.join(config.root,'models')}});
          const instance = worker; instance.once('exit', () => {if (worker === instance) worker = null;});
          instance.on('error', () => {if (worker === instance) worker = null;});
        }
        const current = worker;
        const clean = () => {current.off('message', message); current.off('error', failed); current.off('exit', exited); combined.removeEventListener('abort', abort);};
        const message = (value) => {clean(); if (value.error) reject(new Error(value.error)); else resolve(value);};
        const failed = () => {clean(); if (worker === current) worker = null; reject(new Error('Процесс локального Whisper завершился с ошибкой; повторите выравнивание'));};
        const exited = () => {failed();};
        const abort = () => {clean(); if (worker === current) worker = null; void current.terminate(); reject(combined.reason);};
        current.once('message', message); current.once('error', failed); current.once('exit', exited); combined.addEventListener('abort', abort, {once: true});
        current.postMessage({audio}, [audio.buffer]);
      });
      combined.throwIfAborted();
      return {model: config.whisperModel, chunks: result.chunks || [], timings: alignBlocks(blocks, result.chunks || [], duration)};
    } finally {pending = false;}
  };
  run.close = async () => {const current = worker; worker = null; if (current) await current.terminate();};
  return run;
}
