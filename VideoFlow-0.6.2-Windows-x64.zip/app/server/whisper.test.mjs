import {test} from 'node:test';
import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {mkdtempSync, rmSync, readFileSync, existsSync, writeFileSync} from 'node:fs';
import path from 'node:path';
import {tmpdir} from 'node:os';
import {transcriber} from './alignment.mjs';
import {processFile,ffmpeg} from './media.mjs';
import {atomic} from './core.mjs';

test('Whisper cancellation terminates inference worker; retry reuses cached model path',async(t)=>{
  const root=mkdtempSync(path.join(tmpdir(),'whisper-contract-'));t.after(()=>rmSync(root,{recursive:true,force:true}));
  const audio=path.join(root,'input.mp3');await processFile(ffmpeg,['-y','-f','lavfi','-i','sine=duration=0.4','-c:a','libmp3lame',audio]);
  let started;const posted=new Promise((resolve)=>{started=resolve;});const workers=[];
  const run=transcriber({root,whisperModel:'Xenova/whisper-tiny',whisperTimeout:10000},undefined,{workerFactory:(_url,options)=>{
    const instance=new EventEmitter();instance.terminated=false;instance.options=options;
    instance.postMessage=()=>{if(workers.length===1)started();else queueMicrotask(()=>instance.emit('message',{chunks:[{text:'hola',timestamp:[0,.3]}]}));};
    instance.terminate=async()=>{instance.terminated=true;instance.emit('exit',0);};workers.push(instance);return instance;
  }});t.after(()=>run.close());
  const controller=new AbortController(),pending=run(audio,[{id:'one',text:'hola'}],.4,controller.signal);await posted;controller.abort();
  await assert.rejects(pending,{name:'AbortError'});assert.equal(workers[0].terminated,true);
  const result=await run(audio,[{id:'one',text:'hola'}],.4,new AbortController().signal);
  assert.equal(workers.length,2);assert.equal(result.timings[0].confidence,1);assert.equal(workers[1].options.workerData.cache,path.join(root,'models'));
});
test('disk-full save preserves the previous file and removes partial temporary data', (t)=>{
  const root=mkdtempSync(path.join(tmpdir(),'disk-full-'));t.after(()=>rmSync(root,{recursive:true,force:true}));
  const file=path.join(root,'manifest.json');atomic(file,'previous');let temporary;
  assert.throws(()=>atomic(file,'new',(target)=>{temporary=target;writeFileSync(target,'partial');throw Object.assign(new Error('full'),{code:'ENOSPC'});}),{status:507});
  assert.equal(readFileSync(file,'utf8'),'previous');assert.equal(existsSync(temporary),false);
});
test('audio duration fallback reads the actual file when ffprobe is unavailable',async(t)=>{
  const {validateMedia}=await import('./media.mjs');
  const root=mkdtempSync(path.join(tmpdir(),'duration-fallback-'));t.after(()=>rmSync(root,{recursive:true,force:true}));
  const audio=path.join(root,'audio.unknown');await processFile(ffmpeg,['-y','-f','lavfi','-i','sine=duration=0.4','-c:a','libmp3lame','-f','mp3',audio]);
  const result=await validateMedia(audio,'audio',undefined,{probeFile:async()=>{throw Object.assign(new Error('missing'),{code:'ENOENT'});}});
  assert.equal(result.fallback,'music-metadata');assert.ok(result.duration>=.4&&result.duration<.6);
});
