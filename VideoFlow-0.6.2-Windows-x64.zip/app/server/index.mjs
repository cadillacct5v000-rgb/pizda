import {configuration} from './config.mjs';
import path from 'node:path';
import {frontendStatus} from './frontend.mjs';
import {appDir} from './config.mjs';
import {createApp} from './app.mjs';

const frontend = frontendStatus(path.join(appDir,'dist'));
if (!process.argv.includes('--api-only') && !frontend.ready) {process.stderr.write(frontend.error + '\n'); process.exit(1);}
const config = configuration(), runtime = createApp(config, {requestShutdown: () => {void close();}});
const server = runtime.app.listen(config.port, config.host, () => process.stdout.write(`Video Flow: http://${config.host}:${config.port}\n`));
let closing = false;
async function close() { if (closing) return; closing = true; server.close(); await runtime.close(); server.closeAllConnections(); }
process.on('SIGINT', close); process.on('SIGTERM', close);
server.on('error', async (error) => { process.stderr.write(`Backend failed: ${error.code}\n`); await runtime.close(); process.exitCode = 1; });
