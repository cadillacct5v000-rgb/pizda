import {readFileSync, renameSync, rmSync} from 'node:fs';
import {hash, ensure, AppError, atomic, within, now, redact} from './core.mjs';
import {createGenerationQueue} from './queue.mjs';
import {buildTimeline} from './timeline.mjs';
import {validateMedia, normalizeClip, normalizeImage} from './media.mjs';
import {poll} from './providers.mjs';
import {addLog} from './domain.mjs';
import {validateNarration} from './language.mjs';
import {activeStyle} from './styles.mjs';
import {alignBlocks} from './alignment.mjs';

export function creditCost(usage) {
  const raw=usage?.credits,value=typeof raw==='number'?raw:typeof raw==='string'&&/^\d+(?:\.\d+)?$/.test(raw.trim())?Number(raw):NaN;
  const known=Number.isFinite(value)&&value>=0;
  return {unit:known?'credits':null,value:known?value:null,refunded:typeof usage?.refunded==='boolean'?usage.refunded:null};
}
export function generationService(store, clients, config) {
  const queues = Object.fromEntries(Object.entries(config.concurrency).map(([name, limit]) => [name, createGenerationQueue({name, limit})]));
  for (const operation of store.operations.list()) {
    if (['creating', 'running', 'queued'].includes(operation.status)) store.operations.put({...operation, status: operation.status === 'creating' && !operation.externalId ? 'uncertain' : 'paused'});
  }
  function specification(project, stage, itemId) {
    ensure(['voice', 'image', 'video'].includes(stage), 'Неверный тип генерации');
    const item = (stage === 'voice' ? project.blocks : project.frames).find((candidate) => candidate.id === itemId);
    ensure(item, 'Элемент не найден', 404);
    const provider = stage === 'voice' ? project.models.voiceProvider : stage === 'video' ? project.models.videoProvider || project.models.imageProvider : project.models.imageProvider;
    ensure(provider === (stage === 'voice' ? 'lumean' : 'fal'), 'Обновите настройки проекта: озвучка — Lumean, визуал — fal.ai', 409);
    let payload, duration;
    if (stage === 'voice') {
      ensure(!project.options.voiceoverSkipped && !project.uploads.project && !project.uploads[item.sceneId] && !project.scenes.find((scene) => scene.id === item.sceneId)?.voiceoverSkipped, 'Для этого блока выбрана готовая озвучка или режим без голоса. Новая озвучка не требуется.', 409);
      ensure(item.text.trim(), 'Пустой текст озвучки', 409);
      validateNarration(item.text, project.language);
      ensure(project.models.templateId, 'Выберите шаблон Lumean', 409);
      payload = {template_id: project.models.templateId, input_text: item.text, language: project.language};
    } else {
      ensure(item.approved, `Сначала утвердите кадр ${item.shotId}`, 409);
      ensure(item.imagePrompt.trim(), `Пустой промпт ${item.shotId}`, 409);
      if (stage === 'image') {const style = activeStyle(project); payload = {stage, model: project.models.falImageModel, prompt: item.imagePrompt + (style.instruction ? `\nChannel art direction: ${style.instruction}` : ''),...(style.reference ? {reference:readFileSync(within(store.projectsDir,style.reference.path)).toString('base64')} : {})};}
      else {
        ensure(project.options.animationEnabled && item.image, 'Включите анимацию и создайте изображение', 409);
        const visual = buildTimeline(project, false).visuals.find((frame) => frame.id === itemId);
        duration = visual.durationInFrames / (project.options.fps || 30);
        const image = readFileSync(within(store.projectsDir, item.image.path));
        const prompt = `${item.motionPrompt || 'Subtle natural motion'}. Camera: ${item.camera}`;
        payload = {stage, model: project.models.falVideoModel, prompt, image: image.toString('base64'), duration};
      }
    }
    return {item, provider, payload, duration, fps: project.options.fps || 30, fingerprint: hash({stage, provider, payload})};
  }
  function enqueue(projectId, stage, itemId, {newTake = false, acknowledgeUncertain = false} = {}) {
    const project = store.get(projectId), spec = specification(project, stage, itemId);
    ensure(config.providers[spec.provider]?.key, `Подключите ${spec.provider} в настройках`, 409);
    const key = `${projectId}:${stage}:${itemId}:${spec.fingerprint}`;
    ensure(!queues[stage].stats().keys.some((other) => other !== key && other.startsWith(`${projectId}:${stage}:${itemId}:`)), 'Для этого элемента уже выполняется задача. Дождитесь завершения или отмените её перед новым запуском.', 409);
    let operation = store.operations.get(key);
    ensure(!newTake || !queues[stage].stats().keys.includes(key), 'Генерация уже выполняется', 409);
    if (newTake) {
      ensure(operation?.status !== 'uncertain' || acknowledgeUncertain, 'Предыдущий запрос мог быть оплачен. Проверьте кабинет и подтвердите новый платный запуск.', 409);
      operation = null;
    }
    if (operation?.status === 'uncertain') throw new AppError(409, 'Сервис мог принять запрос, но ответ потерян. Автоповтор отключён во избежание повторной оплаты. Проверьте кабинет.', {operationKey: key, uncertain: true});
    if (operation?.status === 'ready') {
      const asset = stage === 'voice' ? spec.item.audio : spec.item[stage === 'image' ? 'image' : 'video'];
      if (asset) return {key, status: 'ready'};
    }
    if (!operation) operation = {key, projectId, stage, itemId, provider: spec.provider, model: spec.payload.model || String(spec.payload.template_id), fingerprint: spec.fingerprint, status: 'queued', attempt: now(), externalId: null, createdAt: now()};
    store.operations.put(operation);
    queues[stage].enqueue(key, async (signal) => {
      const op = {...operation};
      const client = clients[op.provider]; let temporary, intermediate;
      try {
        signal.throwIfAborted();
        ensure(specification(store.get(projectId), stage, itemId).fingerprint === spec.fingerprint, 'Входные данные изменились. Запустите заново.', 409);
        let bytes, status;
        if (!op.externalId) {
          if (client.validate) await client.validate(spec.payload, signal);
          const prepared = client.prepare ? await client.prepare(spec.payload, signal) : spec.payload;
          ensure(specification(store.get(projectId), stage, itemId).fingerprint === spec.fingerprint, 'Данные изменились во время проверки модели. Генерация не отправлена.', 409);
          op.status = 'creating'; store.operations.put(op);
          store.mutate(projectId, (latest) => {
            const chargeId = `${op.key}:${op.attempt}`;
            if (!latest.cost.some((entry) => entry.id === chargeId)) latest.cost.push({id:chargeId,stage,provider:op.provider,unit:null,value:null,refunded:null});
            return latest;
          });
          {
            const accepted = await client.create(prepared, signal, (externalId) => { op.externalId = externalId; store.operations.put(op); });
            ensure(accepted.id, 'Провайдер не вернул внешний ID', 502);
            op.externalId = String(accepted.id); op.status = 'running'; store.operations.put(op);
          }
        }
        if (!bytes) {
          status = await poll(client, op.externalId, config, signal);
          bytes = await client.result(status, stage, signal);
        }
        signal.throwIfAborted();
        const extension = stage === 'voice' ? 'mp3' : stage === 'image' ? 'png' : 'mp4';
        const folder = stage === 'voice' ? 'audio' : stage === 'image' ? 'images' : 'clips';
        const variant = stage === 'video' ? `-${spec.fps}fps-${hash(String(spec.duration)).slice(0,8)}` : '';
        const relative = `${projectId}/${folder}/${itemId}-${hash(op.attempt).slice(0, 8)}-${spec.fingerprint.slice(0, 12)}${variant}.${extension}`;
        const file = within(store.projectsDir, relative); temporary = `${file}.raw.${extension}`;
        atomic(temporary, bytes);
        const probe = await validateMedia(temporary, stage === 'voice' ? 'audio' : stage, signal);
        if (stage === 'image') {intermediate = `${file}.tmp.png`; await normalizeImage(temporary, intermediate, signal); rmSync(temporary, {force: true}); temporary = intermediate; intermediate = null;}
        if (stage === 'video') {intermediate = `${file}.tmp.mp4`; await normalizeClip(temporary, intermediate, spec.duration, signal, spec.fps); rmSync(temporary, {force: true}); temporary = intermediate; intermediate = null;}
        signal.throwIfAborted(); renameSync(temporary, file); temporary = null;
        const asset = {path: relative, duration: stage === 'image' ? null : stage === 'video' ? spec.duration : probe.duration, sourceDuration: Number.isFinite(probe.duration) ? probe.duration : null, provider: op.provider, model: op.model || spec.payload.model || String(spec.payload.template_id), externalId: op.externalId, inputHash: spec.fingerprint, createdAt: now(), ...(stage === 'image' && status?.resultURL ? {sourceURL: status.resultURL} : {})};
        if (stage === 'voice' && client.alignment) {
          try {
            const chunks = await client.alignment(status, signal);
            if (chunks) {asset.timings = alignBlocks([spec.item], chunks, asset.duration); asset.alignmentModel = 'lumean/service';}
          } catch {asset.alignment = {status: 'error', model: 'lumean/service', error: 'Дополнительный alignment недоступен; аудио сохранено. Используйте локальный Whisper.'};}
          signal.throwIfAborted();
        }
        store.mutate(projectId, (latest) => {
          ensure(specification(latest, stage, itemId).fingerprint === spec.fingerprint, 'Данные изменились; результат сохранён в файлах, но не применён', 409);
          if (stage === 'video') ensure((latest.options.fps || 30) === spec.fps && specification(latest,stage,itemId).duration === spec.duration, 'Настройки монтажа изменились; результат сохранён, но не применён', 409);
          const target = (stage === 'voice' ? latest.blocks : latest.frames).find((item) => item.id === itemId);
          target[stage === 'voice' ? 'audio' : stage] = asset;
          if (stage === 'voice') { target.status = 'ready'; latest.captions = null; latest.frames.filter((f) => f.blockId === itemId).forEach((f) => { f.video = null; }); }
          if (stage === 'image') target.video = null;
          latest.render = null;
          const chargeId = `${op.key}:${op.attempt}`;
          const charge = {id: chargeId, stage, provider: op.provider, ...creditCost(status?.usage)};
          latest.cost = [...latest.cost.filter((entry) => entry.id !== chargeId), charge];
          addLog(latest, 'success', `${stage}: готово`, itemId); return latest;
        });
        op.status = 'ready'; op.asset = asset; op.error = null; store.operations.put(op);
      } catch (error) {
        // A sent POST with no accepted ID is ambiguous, including cancellation and process/network failure.
        const rejected = op.status === 'creating' && !op.externalId && [400,401,402,403,404,405,413,415,422,429].includes(error.details?.providerStatus);
        const uncertain = op.status === 'creating' && !op.externalId && !rejected;
        op.status = uncertain ? 'uncertain' : signal.aborted ? 'cancelled' : 'error';
        op.error = uncertain ? 'Ответ на создание потерян; проверьте кабинет провайдера' : redact(error.message, Object.values(config.providers).map((p) => p.key));
        store.operations.put(op);
        if (rejected) store.mutate(projectId, (latest) => {latest.cost = latest.cost.filter((entry) => entry.id !== `${op.key}:${op.attempt}`); return latest;});
        if (signal.aborted && op.externalId && client.cancel) { try { await client.cancel(op.externalId); } catch { op.cancelUnconfirmed = true; store.operations.put(op); } }
        else if (signal.aborted && op.externalId) {op.cancelUnconfirmed = true; store.operations.put(op);}
        try { store.mutate(projectId, (latest) => { addLog(latest, signal.aborted ? 'warning' : 'error', op.error, itemId); return latest; }); } catch (loggingError) { if (loggingError.status !== 404) throw loggingError; }
        throw error;
      } finally { if (temporary) rmSync(temporary, {force: true}); if (intermediate) rmSync(intermediate, {force: true}); }
    });
    return {key, status: 'queued'};
  }
  return {enqueue, queues, stats: () => Object.values(queues).map((q) => q.stats()),
    cancel(projectId, itemId) { let count = 0; for (const queue of Object.values(queues)) for (const key of queue.stats().keys) if (key.startsWith(`${projectId}:`) && (!itemId || key.split(':')[2] === itemId)) { if (queue.cancel(key)) { count++; const op = store.operations.get(key); if (op?.status === 'queued') store.operations.put({...op, status: 'cancelled'}); } } return count; },
    close: () => Promise.all(Object.values(queues).map((q) => q.close())),
  };
}
