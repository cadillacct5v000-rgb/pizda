import assert from 'node:assert/strict';
import path from 'node:path';
import {mkdirSync, mkdtempSync, readFileSync, writeFileSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {setTimeout as pause} from 'node:timers/promises';
import {configuration, appDir} from '../server/config.mjs';
import {openStore} from '../server/database.mjs';
import {createProject, importRows, scriptRows} from '../server/domain.mjs';
import {generationService} from '../server/generation.mjs';
import {buildTimeline} from '../server/timeline.mjs';
import {renderService} from '../server/render.mjs';
import {processFile, ffmpeg, probe} from '../server/media.mjs';
import {exportArchive, restoreArchive} from '../server/archive.mjs';

const root=mkdtempSync(path.join(tmpdir(),'video-flow-e2e-')),output=path.join(appDir,'test-results');mkdirSync(output,{recursive:true});
const config=configuration({DATA_DIR:root},appDir);config.providers.lumean.key='e2e-fake';config.providers.fal.key='e2e-fake';config.poll=1;
let store=openStore(root),service,renderer;let createCount=0,videoCreates=0;const stages=new Map();
try{
  const image=path.join(root,'input.png'),audio=path.join(root,'input.mp3'),clip=path.join(root,'input.mp4');
  await processFile(ffmpeg,['-y','-f','lavfi','-i','color=c=0x293e2c:s=1920x1080','-frames:v','1','-threads','1',image]);
  await processFile(ffmpeg,['-y','-f','lavfi','-i','sine=frequency=330:duration=0.5','-c:a','libmp3lame',audio]);
  await processFile(ffmpeg,['-y','-f','lavfi','-i','color=c=0x293e2c:s=640x360:d=1','-c:v','libx264','-pix_fmt','yuv420p','-an',clip]);
  const clients={lumean:{create:async()=>({id:'mock-voice'}),status:async()=>({status:'succeeded'}),result:async()=>readFileSync(audio)},fal:{create:async(payload)=>{const id=payload.stage==='video'?`video-${++videoCreates}`:`image-${++createCount}`;stages.set(id,payload.stage);return {id};},status:async(id)=>({status:'succeeded',resultURL:stages.get(id)==='image'?'https://cdn.example/generated.png':undefined,usage:{credits:1}}),result:async(_status,stage)=>readFileSync(stage==='video'?clip:image)}};
  service=generationService(store,clients,config);
  let project=importRows(createProject({title:'E2E · три сцены'}),scriptRows('Первый кадр.\n\nВторой кадр.\n\nТретий кадр.'));
  project.models.templateId='mock-template';project.frames.forEach((f)=>{f.imagePrompt='Forest film scene';f.approved=true;});project=store.put(project,null);
  for(const block of project.blocks)service.enqueue(project.id,'voice',block.id);
  for(const frame of project.frames)service.enqueue(project.id,'image',frame.id);
  const wait=async()=>{for(let count=0;count<3000;count++){if(service.stats().every((q)=>!q.active&&!q.pending))return;await pause(10);}throw new Error('generation timeout');};await wait();
  project=store.get(project.id);assert.equal(project.blocks.filter((b)=>b.audio).length,3);assert.equal(project.frames.filter((f)=>f.image).length,3);
  store.mutate(project.id,(latest)=>{latest.options.animationEnabled=true;for(const block of latest.blocks)block.audio.timings=[{blockId:block.id,start:0,end:block.audio.duration,confidence:1}];return latest;});
  project=store.get(project.id);for(const frame of project.frames)service.enqueue(project.id,'video',frame.id);await wait();project=store.get(project.id);assert.equal(project.frames.filter((frame)=>frame.video).length,3);
  // An existing/imported clip can be shorter than the corrected narration timeline.
  // Rendering/Studio must normalize it locally, without another paid video request.
  await processFile(ffmpeg,['-y','-f','lavfi','-i','color=c=navy:s=320x180:d=0.1','-an','-c:v','libx264','-threads','1',path.join(store.projectsDir,project.frames[0].video.path)]);
  store.mutate(project.id,(p)=>{p.frames[0].video.duration=.1;return p;});project=store.get(project.id);
  const timeline=buildTimeline(project);assert.equal(timeline.visuals.length,3);assert.equal(timeline.audio.length,3);
  renderer=renderService(store,{browserExecutable:process.env.REMOTION_BROWSER_EXECUTABLE});
  const result=await renderer.render(project,new AbortController().signal);await renderer.close();
  const {copyFileSync}=await import('node:fs');copyFileSync(path.join(store.projectsDir,result.path),path.join(output,'three-scenes.mp4'));
  const metadata=await probe(path.join(output,'three-scenes.mp4'));assert.equal(metadata.streams.find((s)=>s.codec_type==='video').width,1920);assert.equal(metadata.streams.find((s)=>s.codec_type==='audio').codec_name,'aac');
  const project60={...project,options:{...project.options,fps:60}};
  const result60=await renderer.render(project60,new AbortController().signal);
  copyFileSync(path.join(store.projectsDir,result60.path),path.join(output,'three-scenes-60fps.mp4'));
  const metadata60=await probe(path.join(output,'three-scenes-60fps.mp4'));assert.equal(metadata60.streams.find((s)=>s.codec_type==='video').r_frame_rate,'60/1');
  const studioURL=await renderer.openStudio(project);assert.equal((await fetch(studioURL)).status,200);
  const {readdirSync}=await import('node:fs');const studioFolder=readdirSync(root).find((name)=>name.startsWith('studio-'));
  const studioProps=JSON.parse(readFileSync(path.join(root,studioFolder,'props.json'),'utf8'));assert.equal(studioProps.timeline.visuals.length,3);const normalized=await probe(path.join(root,studioFolder,'public',studioProps.timeline.visuals[0].path));assert.ok(Math.abs(normalized.duration-studioProps.timeline.visuals[0].durationInFrames/studioProps.timeline.fps)<.1);assert.equal(studioProps.timeline.audio.length,3);await Promise.all([renderer.close(),renderer.close()]);
  const archive=await exportArchive(store,project.id),restored=await restoreArchive(store,archive);assert.equal(buildTimeline(restored).visuals.length,3);
  assert.equal(videoCreates,3);assert.equal(project.cost.length,9);
  await service.close();store.close();store=openStore(root);service=generationService(store,clients,config);project=store.get(project.id);
  for(const frame of project.frames)service.enqueue(project.id,'image',frame.id);await wait();assert.equal(createCount,3);
  const many=importRows(createProject(),scriptRows(Array.from({length:202},(_,i)=>`Сцена ${i+1}.`).join('\n\n')));many.options.voiceoverSkipped=true;many.frames.forEach((f)=>{f.image={path:'fixture.png'};});
  assert.equal(buildTimeline(many).visuals.length,202);many.options.subtitlesEnabled=false;assert.equal(buildTimeline(many).cues.length,0);
  writeFileSync(path.join(output,'e2e-report.json'),JSON.stringify({passed:true,scenes:3,paidRequests:0,mockImageCreates:createCount,mockVideoCreates:videoCreates,animation:true,restartDidNotRecreate:true,archiveRestored:true,stressFrames:202,duration:metadata.duration,video:metadata.streams.find((s)=>s.codec_type==='video'),audio:metadata.streams.find((s)=>s.codec_type==='audio')},null,2));
  process.stdout.write('E2E passed: three scenes → real Remotion MP4; archive/restore; restart/cache; 202-frame dry run. No paid API calls.\n');
}finally{await renderer?.close();await service?.close();store.close();rmSync(root,{recursive:true,force:true});}
