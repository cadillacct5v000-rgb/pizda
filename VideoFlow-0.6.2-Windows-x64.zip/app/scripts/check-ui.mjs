import assert from 'node:assert/strict';
import {mkdtempSync, rmSync, mkdirSync, readFileSync} from 'node:fs';
import path from 'node:path';
import {tmpdir} from 'node:os';
import {chromium} from '@playwright/test';
import {createApp} from '../server/app.mjs';
import {configuration, appDir} from '../server/config.mjs';
import {processFile,ffmpeg} from '../server/media.mjs';
import {falModels} from '../server/fal-client.mjs';

const root=mkdtempSync(path.join(tmpdir(),'flow-ui-')),config=configuration({DATA_DIR:root,VIDEO_FLOW_CONFIG_DIR:root},appDir);
config.providers.fal.key='ui-fixture';config.providers.lumean.key='ui-fixture';
const models=falModels(JSON.parse(readFileSync(new URL('../server/fixtures/fal-models.json',import.meta.url),'utf8')));
const textRequests=[],styleRequests=[];
const mockFal={check:async()=>({models}),validateText:async()=>{},createText:async(input,_signal,checkpoint)=>{const id=String(textRequests.push(JSON.parse(input.prompt)));checkpoint(id);return {id};},status:async(id)=>({status:'succeeded',id}),textResult:async({id})=>{const input=textRequests[Number(id)-1];return {output:JSON.stringify({language:input.target_language,blocks:input.blocks.map((block)=>({...block,text:input.target_language==='ro'?'O poveste despre ocean.':`Улучшено: ${block.text}`}))}),usage:{cost:.01}};}};
mockFal.validate=async()=>{};mockFal.prepare=async(p)=>p;mockFal.create=async(p,_signal,checkpoint)=>{const id=String(styleRequests.push(p));checkpoint(id);return {id};};mockFal.result=async()=>readFileSync(path.join(root,'reference.png'));
const runtime=createApp(config,{clients:{fal:mockFal,lumean:{check:async()=>({templates:[{id:'spanish',name:'Испанский диктор',service:'elevenlabs',language:'es'}]})}}});
const server=runtime.app.listen(0,'127.0.0.1');await new Promise((resolve)=>server.once('listening',resolve));
let browser;
try{
  browser=await chromium.launch({headless:true,executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE});
  const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];page.on('pageerror',(error)=>errors.push(error.message));
  await page.goto(`http://127.0.0.1:${server.address().port}`);await page.getByRole('button',{name:'＋ Новый проект'}).click();
  const modal=page.getByRole('dialog');await modal.getByLabel('Название',{exact:true}).focus();for(let i=0;i<16;i++){await page.keyboard.press('Tab');assert.equal(await page.evaluate(()=>!!document.activeElement?.closest('dialog')),true,JSON.stringify(await page.evaluate(()=>({active:document.activeElement?.outerHTML.slice(0,350),dialogs:Array.from(document.querySelectorAll('dialog')).map((d)=>({open:d.open,modal:d.matches(':modal')}))}))));}assert.equal(await modal.getByLabel('Ссылка YouTube',{exact:true}).count(),0);await modal.getByLabel('Название',{exact:true}).fill('Проверка интерфейса');await modal.getByLabel('Сценарий',{exact:true}).fill('Первая сцена.\n\nВторая сцена.\n\nТретья сцена.');await modal.getByRole('button',{name:'Создать проект',exact:true}).click();
  await page.getByRole('heading',{name:'Проверка интерфейса',exact:true}).waitFor();assert.ok(page.url().includes('/draft'));
  await page.getByRole('navigation',{name:'Этапы'}).getByRole('button',{name:/Раскадровка/}).click();
  const prompt=page.getByLabel('Промпт изображения',{exact:true}).first();await prompt.fill('Тёмный кинематографичный лес');
  // Navigate before debounce: pending editor text must be flushed and survive reload.
  await page.getByRole('navigation',{name:'Этапы'}).getByRole('button',{name:/Изображения/}).click();await page.waitForURL(/\/images$/);await page.reload();
  await page.getByLabel('Промпт изображения',{exact:true}).first().waitFor();assert.equal(await page.getByLabel('Промпт изображения',{exact:true}).first().inputValue(),'Тёмный кинематографичный лес');
  assert.equal(await page.getByRole('navigation',{name:'Этапы'}).getByRole('button',{name:/Анимация/}).count(),0);
  await page.getByRole('button',{name:'Подключения и ключи'}).click();await page.getByRole('dialog').waitFor();assert.equal(await page.locator('input[type=password]').count(),2);
  for(const provider of ['fal.ai','Lumean']){
    const section=page.getByRole('dialog').locator('section').filter({has:page.getByRole('heading',{name:new RegExp('^'+provider+' —')})});
    await section.getByRole('button',{name:'Проверить подключение'}).click();await section.getByText('Подключено',{exact:true}).waitFor();
  }
  assert.equal(await page.getByRole('dialog').getByText(/SYNTX|FastGen|ElevenLabs — прямой/).count(),0);await page.keyboard.press('Escape');
  await page.getByLabel('Модель изображения fal.ai').waitFor();assert.equal(await page.getByLabel('Модель изображения fal.ai').locator('option').count(),4);
  assert.equal(await page.getByLabel('Модель изображения fal.ai').inputValue(),'fal-ai/nano-banana-pro');
  const referenceFile=path.join(root,'reference.png');await processFile(ffmpeg,['-y','-f','lavfi','-i','color=c=teal:s=320x180','-frames:v','1','-threads','1',referenceFile]);
  await page.getByLabel('Образец стиля для Nano Banana',{exact:true}).setInputFiles(referenceFile);
  await page.getByRole('img',{name:'Образец стиля',exact:true}).waitFor();assert.ok(runtime.store.list()[0].visualReference);
  await page.getByLabel('Модель изображения fal.ai').selectOption('fal-ai/nano-banana-2');
  await page.getByLabel('Модель изображения fal.ai').selectOption('fal-ai/nano-banana-pro');
  page.on('dialog',(dialog)=>dialog.accept());
  await page.getByLabel('Тестовая сцена для сравнения',{exact:true}).fill('An orca swimming in the ocean in the reference visual medium');
  await page.getByRole('button',{name:'Создать или продолжить 3 варианта',exact:true}).click();
  for(const name of ['A','B','C'])await page.getByRole('button',{name:`Выбрать вариант ${name}`,exact:true}).waitFor({state:'visible'});
  await page.getByRole('button',{name:'Выбрать вариант B',exact:true}).click();
  await page.getByRole('button',{name:'Выбран для ролика',exact:true}).waitFor();
  assert.equal(styleRequests.length,3);assert.ok(runtime.store.list()[0].channelStyle.id.endsWith(':b'));
  await page.reload();await page.getByRole('button',{name:'Выбран для ролика',exact:true}).waitFor();
  assert.equal(styleRequests.length,3);
  mkdirSync(path.join(appDir,'test-results'),{recursive:true});await page.screenshot({path:path.join(appDir,'test-results/three-styles.png'),fullPage:true});
  await page.getByRole('button',{name:'Убрать образец стиля',exact:true}).click();await page.getByRole('img',{name:'Образец стиля',exact:true}).waitFor({state:'hidden'});assert.equal(runtime.store.list()[0].visualReference,undefined);
  const steps=page.getByRole('navigation',{name:'Этапы'});
  await steps.getByRole('button',{name:/Черновик/}).click();await page.waitForURL(/\/draft$/);
  await page.getByLabel('Анимация',{exact:true}).click();await steps.getByRole('button',{name:/Анимация/}).waitFor();
  await page.getByLabel('Текстовая модель',{exact:true}).selectOption('anthropic/claude-sonnet-5.5');
  await page.getByRole('button',{name:'Улучшить сценарий',exact:true}).click();
  await page.getByRole('heading',{name:/Сравнение · 3 реплик/}).waitFor();
  assert.equal(runtime.store.list()[0].blocks[0].text,'Первая сцена.');
  await page.getByRole('button',{name:'Применить вариант Claude',exact:true}).click();
  await page.getByRole('heading',{name:/Сравнение · 3 реплик/}).waitFor({state:'hidden'});
  assert.equal(runtime.store.list()[0].blocks[0].text,'Улучшено: Первая сцена.');
  await page.getByLabel('Язык перевода',{exact:true}).selectOption('ro');
  await page.getByRole('button',{name:'Перевести и адаптировать',exact:true}).click();
  await page.getByRole('heading',{name:/Сравнение · 3 реплик · ro/}).waitFor();
  assert.equal(runtime.store.list()[0].language,'ru');
  await page.getByRole('button',{name:'Применить вариант Claude',exact:true}).click();
  await page.getByRole('heading',{name:/Сравнение · 3 реплик/}).waitFor({state:'hidden'});
  assert.equal(runtime.store.list()[0].language,'ro');assert.equal(textRequests.length,2);
  await page.screenshot({path:path.join(appDir,'test-results/claude-interface.png'),fullPage:true});
  for(const language of ['ro','es','pt-BR','pt-PT']){await page.getByLabel('Язык сценария',{exact:true}).selectOption(language);await page.waitForFunction((value)=>document.querySelector('select[aria-label="Язык сценария"]')?.value===value,language);}
  await steps.getByRole('button',{name:/Озвучка/}).click();await page.waitForURL(/\/voiceover$/);
  await page.getByLabel('Шаблон Lumean').selectOption('spanish');await page.waitForTimeout(150);
  await steps.getByRole('button',{name:/Анимация/}).click();await page.waitForURL(/\/animation$/);
  assert.equal(await page.getByLabel('Модель оживления fal.ai').inputValue(),'fal-ai/kling-video/v3/pro/image-to-video');
  assert.equal(await page.getByLabel('Модель оживления fal.ai').locator('option').count(),3);
  await page.getByLabel('Модель оживления fal.ai').selectOption('fal-ai/kling-video/v3/pro/image-to-video');
  assert.equal(runtime.store.list()[0].models.falVideoModel,'fal-ai/kling-video/v3/pro/image-to-video');
  assert.equal(runtime.store.list()[0].models.templateId,'spanish');
  mkdirSync(path.join(appDir,'test-results'),{recursive:true});await page.screenshot({path:path.join(appDir,'test-results/interface.png'),fullPage:true});
  for(const width of [1280,1920]){await page.setViewportSize({width,height:1000});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth),true);}
  const savedURL=page.url();await page.goto(`http://127.0.0.1:${server.address().port}/projects/00000000-0000-0000-0000-000000000000/draft`);await page.waitForURL(`http://127.0.0.1:${server.address().port}/`);await page.goto(savedURL);await page.getByRole('heading',{name:'Проверка интерфейса',exact:true}).waitFor();
  assert.deepEqual(errors,[]);assert.equal(runtime.store.list().length,1);process.stdout.write('Browser smoke passed: create, navigate, autosave on navigation, reload, settings, fal.ai image/video catalog separation, Lumean templates, Claude rewrite/translation/compare/apply, RO/ES/PT language choices, no JavaScript errors.\n');
}finally{await browser?.close();await new Promise((resolve)=>server.close(resolve));await runtime.close();rmSync(root,{recursive:true,force:true});}
