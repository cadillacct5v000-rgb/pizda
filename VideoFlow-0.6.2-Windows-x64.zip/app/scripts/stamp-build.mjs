import {readFileSync,writeFileSync,readdirSync} from 'node:fs';
import path from 'node:path';
import {appDir} from '../server/config.mjs';
import {hash} from '../server/core.mjs';
const dist=path.join(appDir,'dist'),files={};
function walk(folder){for(const entry of readdirSync(folder,{withFileTypes:true})){const file=path.join(folder,entry.name);if(entry.isDirectory())walk(file);else if(entry.name!=='build.json')files[path.relative(dist,file).split(path.sep).join('/')]=hash(readFileSync(file).toString('base64'));}}
walk(dist);if(!files['index.html'])throw Error('Frontend index is missing');
writeFileSync(path.join(dist,'build.json'),JSON.stringify({version:JSON.parse(readFileSync(path.join(appDir,'package.json'),'utf8')).version,files}));
