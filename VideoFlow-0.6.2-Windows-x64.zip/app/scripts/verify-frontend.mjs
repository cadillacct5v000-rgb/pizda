import path from 'node:path';
import {appDir} from '../server/config.mjs';
import {frontendStatus} from '../server/frontend.mjs';
const status=frontendStatus(path.join(appDir,'dist'));
if(!status.ready){process.stderr.write(status.error+'\n');process.exitCode=1;}else process.stdout.write(`Frontend ${status.version}: verified\n`);
