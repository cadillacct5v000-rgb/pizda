import {test} from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,existsSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {browserCandidates,browserReceipt,resolveBrowser,prepareBrowser,clearRecoveredInstallFailure,browserMode,probeBrowser} from './browser.mjs';
const temporary=()=>mkdtempSync(path.join(tmpdir(),'flow-browser-'));
test('installed browser is actually probed and persisted without downloading',async()=>{
 let downloads=0,saved;const seen=[];
 const result=await prepareBrowser({candidates:['existing-edge'],probe:async(file)=>seen.push(file),download:async()=>{downloads++;throw Error('ECONNRESET');},save:(value)=>saved=value,log:()=>{}});
 assert.equal(downloads,0);assert.deepEqual(seen,['existing-edge']);assert.deepEqual(result,saved);assert.equal(result.source,'installed');
});
test('a broken browser does not prevent using the next installed browser',async()=>{
 const seen=[];const result=await prepareBrowser({candidates:['broken-chrome','working-edge'],probe:async(file)=>{seen.push(file);if(file==='broken-chrome')throw Error('launch failed');},download:async()=>{throw Error('Must not download');},save:()=>{},log:()=>{}});
 assert.deepEqual(seen,['broken-chrome','working-edge']);assert.equal(result.path,'working-edge');
});
test('download fallback is probed before it is saved',async()=>{
 const events=[];const result=await prepareBrowser({candidates:[],download:async()=>{events.push('download');return {path:'downloaded-browser'};},probe:async()=>events.push('probe'),save:()=>events.push('save'),log:()=>{}});
 assert.deepEqual(events,['download','probe','save']);assert.equal(result.source,'downloaded');
});
test('connection reset and invalid downloaded browsers never produce a success receipt',async()=>{
 for(const download of [async()=>{throw Object.assign(Error('aborted'),{code:'ECONNRESET'});},async()=>({path:'broken-download'})]){
  let saved=false;await assert.rejects(prepareBrowser({candidates:[],download,probe:async()=>{throw Error('Cannot start');},save:()=>{saved=true;},log:()=>{}}),/Chrome\/Edge/);assert.equal(saved,false);
 }
});
test('Windows system Chrome and Edge paths and a validated receipt are discovered without a network call',()=>{
 const root=temporary();try{
  const directory=path.join(root,'app'),config=path.join(root,'config'),programs=path.join(root,'programs'),environment={ProgramFiles:programs,VIDEO_FLOW_CONFIG_DIR:config};
  const edge=path.join(programs,'Microsoft','Edge','Application','msedge.exe');mkdirSync(path.dirname(edge),{recursive:true});writeFileSync(edge,'fake unit fixture');
  assert.deepEqual(browserCandidates({environment,platform:'win32',directory}),[edge]);
  mkdirSync(config);writeFileSync(browserReceipt(environment,directory),JSON.stringify({path:edge,source:'installed'}));
  assert.equal(resolveBrowser({environment,platform:'win32',directory}),edge);
  writeFileSync(browserReceipt(environment,directory),'broken JSON');assert.equal(resolveBrowser({environment,platform:'win32',directory}),edge);
  environment.REMOTION_BROWSER_EXECUTABLE='relative.exe';assert.equal(browserCandidates({environment,platform:'win32',directory}).includes('relative.exe'),false);
 }finally{rmSync(root,{recursive:true,force:true});}
});
test('successful old-version update can recover its failed-browser-install marker without touching keys or active installer',()=>{
 const root=temporary();try{
  const directory=path.join(root,'app'),config=path.join(root,'config'),environment={VIDEO_FLOW_CONFIG_DIR:config};mkdirSync(directory);mkdirSync(config);
  const marker=path.join(root,'install.failed'),keys=path.join(config,'.env.local');writeFileSync(path.join(root,'package-manifest.json'),'{}');writeFileSync(marker,'Remotion browser installation failed');writeFileSync(keys,'FAL_API_KEY=unit-placeholder');
  writeFileSync(path.join(root,'install.pid'),'123');assert.equal(clearRecoveredInstallFailure({environment,directory}),false);assert.ok(existsSync(marker));rmSync(path.join(root,'install.pid'));
  assert.equal(clearRecoveredInstallFailure({environment,directory:path.join(root,'unrelated')}),false);assert.ok(existsSync(marker));
  assert.equal(clearRecoveredInstallFailure({environment,directory}),true);assert.equal(existsSync(marker),false);assert.equal(readFileSync(keys,'utf8'),'FAL_API_KEY=unit-placeholder');
 }finally{rmSync(root,{recursive:true,force:true});}
});

test('system Chrome and Edge use modern headless mode; bundled Headless Shell keeps its own mode',async()=>{
 assert.equal(browserMode('msedge.exe'),'chrome-for-testing');assert.equal(browserMode('chrome.exe'),'chrome-for-testing');assert.equal(browserMode('chrome-headless-shell.exe'),'headless-shell');assert.equal(browserMode(undefined),'headless-shell');
 const seen=[];let closed=false;await probeBrowser('msedge.exe',{launch:async(name,options)=>{seen.push({name,...options});return {close:async()=>{closed=true;}};}});
 assert.equal(seen[0].chromeMode,'chrome-for-testing');assert.equal(seen[0].browserExecutable,'msedge.exe');assert.equal(closed,true);
});
