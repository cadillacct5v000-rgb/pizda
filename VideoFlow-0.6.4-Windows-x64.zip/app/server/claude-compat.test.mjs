import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {falClient,claudeModels} from './fal-client.mjs';
const capabilities=JSON.parse(readFileSync(new URL('./fixtures/claude-capabilities.json',import.meta.url),'utf8'));
test('Claude 5.5 submit respects published model sampling capabilities',async()=>{
 const sampling=['temperature','top_p','top_k','max_tokens','reasoning'];let requests=0;
 const config={providers:{fal:{base:'https://queue.fal.run',key:'contract-placeholder'}}};
 const client=falClient(config,async(_name,route,options)=>{
  requests++;assert.equal(route,'/openrouter/router');const input=options.body,model=capabilities.models.find((m)=>m.id===input.model);assert.ok(model);
  const invalid=sampling.filter((key)=>Object.hasOwn(input,key)&&!model.supported_parameters.includes(key));
  assert.deepEqual(invalid,[],`Provider rejects unsupported model parameters: ${invalid.join(', ')}`);
  return {request_id:'verified',status_url:'https://queue.fal.run/openrouter/router/requests/verified/status',response_url:'https://queue.fal.run/openrouter/router/requests/verified',cancel_url:'https://queue.fal.run/openrouter/router/requests/verified/cancel'};
 },async()=>{});
 for(const model of claudeModels)await client.createText({model:model.value,prompt:'contract input',systemPrompt:'editor'},new AbortController().signal);
 assert.equal(requests,3);
});
