// Never surface raw provider payloads, narration, credentials or validation `input`.
// Diagnostics consist only of known field names and locally authored explanations.
const fields=new Set(['prompt','system_prompt','model','max_tokens','temperature','reasoning','input_text','template_id','duration','image_url','start_image_url','image_size','aspect_ratio','resolution','num_images','output_format','context','generate_audio']);
function explanation(type,message=''){
 const value=String(type||'')+' '+String(message||'');
 if(/content_policy|safety|moderation|content.*filter/i.test(value))return 'сервис отклонил содержимое по своей политике';
 if(/unsupported|not supported|not allowed|extra_forbidden/i.test(value))return 'параметр не поддерживается выбранной моделью';
 if(/model.*(?:not found|unknown|unavailable)|(?:unknown|unavailable).*model/i.test(value))return 'модель недоступна в этом маршруте';
 if(/missing|required/i.test(value))return 'отсутствует обязательный параметр';
 if(/less_than|too_long|maximum|max length/i.test(value))return 'превышен допустимый предел';
 if(/greater_than|too_short|minimum|min length/i.test(value))return 'значение ниже допустимого предела';
 if(/_type|type_error|must be|should be a valid/i.test(value))return 'неверный тип значения';
 if(/balance|credit|payment|quota/i.test(value))return 'проверьте баланс и ограничения аккаунта';
 return 'значение не принято сервисом';
}
async function boundedJson(response,limit=16384){
 if(response.body?.getReader){
  const reader=response.body.getReader();let size=0;const chunks=[];
  try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>limit){await reader.cancel();return null;}chunks.push(value);}return JSON.parse(Buffer.concat(chunks).toString('utf8'));}
  finally{reader.releaseLock();}
 }
 if(typeof response.json==='function'){const result=await response.json();return Buffer.byteLength(JSON.stringify(result))<=limit?result:null;}
 return null;
}
export async function providerValidationSummary(response){
 if(![400,422].includes(response.status))return '';
 try{
  const payload=await boundedJson(response);if(!payload||typeof payload!=='object')return '';
  const list=Array.isArray(payload.detail)?payload.detail.slice(0,3):[{msg:typeof payload.detail==='string'?payload.detail:payload.error?.message||payload.message,type:payload.error?.code||payload.code}];
  return [...new Set(list.filter((item)=>item&&typeof item==='object').map((item)=>{
   const location=Array.isArray(item.loc)?item.loc.filter((part)=>typeof part==='string'&&fields.has(part)).slice(0,3).join('.'):'запрос';
   return `${location||'запрос'}: ${explanation(item.type,item.msg)}`;
  }))].join('; ');
 }catch{return '';}
}
