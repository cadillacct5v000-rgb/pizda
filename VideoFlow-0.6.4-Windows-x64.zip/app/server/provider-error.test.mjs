import {test} from 'node:test';
import assert from 'node:assert/strict';
import {providerValidationSummary} from './provider-error.mjs';
import {providerClients} from './providers.mjs';
test('422 names the unsupported field without echoing provider input, keys or narration',async()=>{
 const response=Response.json({detail:[{loc:['body','temperature'],msg:'Temperature is not supported for selected model; api-key secret-placeholder and private narration',type:'unsupported_parameter',input:'secret-placeholder',ctx:{token:'secret-placeholder'}}]},{status:422});
 const summary=await providerValidationSummary(response);assert.equal(summary,'temperature: параметр не поддерживается выбранной моделью');assert.doesNotMatch(summary,/secret|private narration|api-key/);
});
test('validation diagnostics normalize limits, missing fields and malformed errors',async()=>{
 assert.equal(await providerValidationSummary(Response.json({detail:[{loc:['body','max_tokens'],msg:'above maximum',type:'less_than_equal'}]},{status:422})),'max_tokens: превышен допустимый предел');
 assert.equal(await providerValidationSummary(Response.json({detail:[{loc:['body','private-secret-field'],type:'missing',input:'do not expose'}]},{status:422})),'запрос: отсутствует обязательный параметр');
 assert.equal(await providerValidationSummary(new Response('not json',{status:422})), '');
 assert.equal(await providerValidationSummary(Response.json({message:'private details'},{status:401})), '');
});
test('provider validation body is bounded and raw error messages are not reflected',async()=>{
 assert.equal(await providerValidationSummary(Response.json({detail:'secret'.repeat(10000)},{status:422})), '');
 assert.equal(await providerValidationSummary(Response.json({detail:'credential-placeholder: arbitrary upstream payload'},{status:422})),'запрос: значение не принято сервисом');
});
test('a rejected paid POST preserves status and safe diagnostic and is never retried',async()=>{
 let calls=0;const clients=providerClients({httpTimeout:1000,providers:{fal:{base:'https://queue.fal.run',key:'test-placeholder'}}},async()=>{calls++;return Response.json({detail:[{loc:['body','model'],type:'value_error',msg:'Model unavailable',input:'private input'}]},{status:422});});
 await assert.rejects(clients.request('fal','/openrouter/router',{method:'POST',body:{prompt:'private narration'}}),(error)=>{assert.equal(error.details.providerStatus,422);assert.match(error.message,/model: модель недоступна/);assert.doesNotMatch(error.message,/private/);return true;});assert.equal(calls,1);
});
