import {prepareBrowser,clearRecoveredInstallFailure} from '../server/browser.mjs';
try{await prepareBrowser();if(clearRecoveredInstallFailure())console.log('Previous failed installation recovered after successful verification.');}
catch(error){console.error(error.message);console.error(error.cause?.code || error.cause?.message || '');process.exitCode=1;}
