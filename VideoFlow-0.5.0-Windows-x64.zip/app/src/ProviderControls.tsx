import type {AppState, Project, ProjectPatch, CatalogModel} from './types';
import {useState} from 'react';
import {api} from './lib/api';

interface Props {
  project: Project; state: AppState; busy: boolean;
  save: (patch: ProjectPatch) => Promise<void>;
  run: (action: () => Promise<unknown>) => Promise<void>;
}
function ModelSelect({label, value, models, disabled, change}: {
  label: string; value: string; models: CatalogModel[]; disabled: boolean; change: (model: CatalogModel) => void;
}) {
  return <label className="field">{label}<select aria-label={label} value={value} disabled={disabled || !models.length} onChange={(event) => {
    const model = models.find((item) => item.value === event.target.value); if (model) change(model);
  }}>
    {!models.some((model) => model.value === value) && <option value={value}>{value || 'Выберите модель'} · обновите каталог</option>}
    {models.map((model) => <option key={model.value} value={model.value}>{model.label}</option>)}
  </select></label>;
}
export function VisualControls({project, state, busy, save, run}: Props) {
  const [referenceVersion,setReferenceVersion] = useState(0);
  const integration = state.integrations.fal, models = integration?.details?.models || [];
  const imageModels = models.filter((model) => model.kind === 'image');
  const videoModels = models.filter((model) => model.kind === 'video');
  return <>
    <h2>fal.ai · изображения и оживление</h2>
    <div className="toolbar"><button disabled={busy} onClick={() => {void run(() => api.connect('fal'));}}>Обновить модели fal.ai</button><span role="status">{integration?.status === 'connected' ? 'fal.ai подключён' : 'Подключите fal.ai в разделе «Подключения и ключи»'}</span></div>
    <div className="columns"><ModelSelect label="Модель изображения fal.ai" value={project.models.falImageModel} models={imageModels} disabled={busy} change={(model) => {void run(() => save({models: {falImageModel: model.value}}));}}/>
    {project.options.animationEnabled && <ModelSelect label="Модель оживления fal.ai" value={project.models.falVideoModel} models={videoModels} disabled={busy} change={(model) => {void run(() => save({models: {falVideoModel: model.value}}));}}/>}</div>
    <p>Nano Banana 2 и Pro — изображения Gemini; Seedance и Kling — оживление готового кадра. Генерация собственного звука отключена там, где она поддерживается: голос берётся из Lumean. Для новых проектов выбраны Nano Banana Pro и Kling 3 Pro.</p>
    <label className="field">Образец стиля для Nano Banana<input key={referenceVersion} aria-label="Образец стиля для Nano Banana" type="file" accept="image/png,image/jpeg,image/webp" disabled={busy} onChange={(event) => {const file = event.target.files?.[0]; if (!file) return; void run(async() => {
      if (file.size > 25 * 1024 * 1024) throw new Error('Образец: максимум 25 МБ');
      await save({models:{falImageModel:project.models.falImageModel}});
      const current = await api.project(project.id);
      const data = await new Promise<string>((resolve,reject) => {const reader = new FileReader(); reader.onerror = () => reject(new Error('Не удалось прочитать образец')); reader.onload = () => resolve(String(reader.result).split(',')[1]); reader.readAsDataURL(file);});
      await api.visualReference(project.id,current.revision,data); setReferenceVersion((value) => value + 1);
    });}}/></label>
    {project.visualReference && <div className="toolbar"><img src={`/files/${project.visualReference.path}`} alt="Образец стиля" style={{width:160,height:90,objectFit:'contain'}}/><button disabled={busy} onClick={() => {void run(async() => {const current = await api.project(project.id); await api.visualReference(project.id,current.revision,undefined,true);});}}>Убрать образец стиля</button></div>}
    <p>Образец отправляется в Nano Banana вместе с каждым новым запросом изображения. Он помогает удерживать стиль, но не гарантирует одинаковых персонажей. Загрузка и замена образца не запускают генерацию и не меняют готовые кадры. Для обновления готового кадра создайте новый вариант.</p>
    <p>Модели разделены по назначению. Исходный кадр загружается напрямую в fal.ai. Готовые задачи сохраняются по ID и продолжаются после сбоя без новой отправки. Для изображений и оживления доступны отдельные модели.</p>
    {integration?.error && <p className="error">{integration.error}</p>}
  </>;
}
export function VoiceControls({project, state, busy, save, run}: Props) {
  const templates = state.integrations.lumean?.details?.templates || [];
  return <>
    <h3>Lumean · шаблон озвучки</h3>
    <p>Шаблон определяет голос и подачу. Выберите шаблон для языка сценария: {project.language}. Выбор языка проекта не переводит готовый текст.</p>
    <button disabled={busy} onClick={() => {void run(() => api.connect('lumean'));}}>Обновить шаблоны Lumean</button>
    <label className="field">Шаблон Lumean<select disabled={busy || !templates.length} value={project.models.templateId} onChange={(event) => {void run(() => save({models: {templateId: event.target.value}}));}}>
      <option value="">Выберите шаблон</option>
      {project.models.templateId && !templates.some((template) => String(template.id) === project.models.templateId) && <option value={project.models.templateId}>{project.models.templateId} · обновите каталог</option>}
      {templates.map((template) => <option key={template.id} value={String(template.id)}>{template.name} · {template.service}</option>)}
    </select></label>
    {state.integrations.lumean?.error && <p className="error">{state.integrations.lumean.error}</p>}
  </>;
}
