import path from 'node:path';
import {readFileSync,statSync,existsSync,unlinkSync} from 'node:fs';
import {openBrowser,ensureBrowser} from '@remotion/renderer';
import {appDir} from './config.mjs';
import {atomic} from './core.mjs';

const fileExists=(file)=>{try{return path.isAbsolute(file)&&statSync(file).isFile();}catch{return false;}};
export function browserReceipt(environment=process.env,directory=appDir){return path.join(environment.VIDEO_FLOW_CONFIG_DIR || path.join(directory,'node_modules','.cache'),'browser.json');}
export function browserCandidates({environment=process.env,platform=process.platform,directory=appDir,exists=fileExists}={}){
  const candidates=[environment.REMOTION_BROWSER_EXECUTABLE];
  try{candidates.push(JSON.parse(readFileSync(browserReceipt(environment,directory),'utf8')).path);}catch{/* No validated browser yet. */}
  if(platform==='win32'){
    for(const base of [environment.ProgramFiles,environment['ProgramFiles(x86)'],environment.LOCALAPPDATA])if(base){
      candidates.push(path.join(base,'Google','Chrome','Application','chrome.exe'),path.join(base,'Microsoft','Edge','Application','msedge.exe'));
    }
    candidates.push(path.join(directory,'node_modules','.remotion','chrome-headless-shell','win64','chrome-headless-shell-win64','chrome-headless-shell.exe'));
  }else if(platform==='darwin')candidates.push('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge');
  else candidates.push('/usr/bin/chromium','/usr/bin/chromium-browser','/usr/bin/google-chrome');
  return [...new Set(candidates.filter((file)=>typeof file==='string'&&file&&exists(file)))];
}
export function resolveBrowser(options){return browserCandidates(options)[0];}
export async function probeBrowser(executable){
  const browser=await openBrowser('chrome',{browserExecutable:executable,logLevel:'error'});
  try{return executable;}finally{await browser.close({silent:true});}
}
export async function prepareBrowser({candidates=browserCandidates(),probe=probeBrowser,download=()=>ensureBrowser({logLevel:'info'}),save=(result)=>atomic(browserReceipt(),JSON.stringify(result)),log=console.log}={}){
  for(const executable of candidates){
    try{await probe(executable);const result={path:executable,source:'installed'};save(result);log(`Render browser ready: ${path.basename(executable)} (already installed; no download)`);return result;}
    catch{log(`Render browser unavailable: ${path.basename(executable)}; trying another candidate`);}
  }
  let result;
  try{const downloaded=await download();if(!downloaded.path)throw Error('Browser download did not return a usable file');await probe(downloaded.path);result={path:downloaded.path,source:'downloaded'};}
  catch(error){throw new Error('Render browser setup failed: Chrome/Edge could not be started and the Remotion download failed. Existing application data is preserved. Run Install again after installing Chrome/Edge or restoring the download connection.',{cause:error});}
  save(result);log('Render browser ready: downloaded and verified');return result;
}
export function clearRecoveredInstallFailure({environment=process.env,directory=appDir}={}){
  const config=environment.VIDEO_FLOW_CONFIG_DIR;if(!config)return false;
  const root=path.dirname(path.resolve(config)),canonical=(value)=>process.platform==='win32'?path.resolve(value).toLowerCase():path.resolve(value);
  if(path.basename(config)!=='config'||canonical(directory)!==canonical(path.join(root,'app'))||!existsSync(path.join(root,'package-manifest.json'))||existsSync(path.join(root,'install.pid')))return false;
  const marker=path.join(root,'install.failed');if(!existsSync(marker))return false;unlinkSync(marker);return true;
}
