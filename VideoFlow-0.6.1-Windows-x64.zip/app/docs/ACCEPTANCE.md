# Сверка с 40 шагами документа

Основа: AI_Video_Flow_40_AI_prompts.docx. Изменение по указанию пользователя ровно одно на уровне провайдеров: **SYNTX → fal.ai**. Lumean, локальный Whisper, React/Express/SQLite и Remotion/FFmpeg сохранены. Этот отчёт различает реализацию, автоматическую проверку и ручную приёмку; не объявляет успешной реальную платную генерацию без ключей.

| № | Требование | Реализация / доказательство |
|---|---|---|
| 01 | Среда и Node LTS | engines >=20.19, локальный Node24, встроенный проверяемый Windows Node. Потребительская Windows — отдельная проверка |
| 02 | Git и правила | Существующий репозиторий сохранён; runtime/ключи/медиа игнорируются, изменения изолированы от прежнего Python-конвейера |
| 03 | Продукт и архитектура | PRODUCT_SPEC.md, ARCHITECTURE.md: сценарий → голос → кадры → изображения → видео → субтитры → MP4 |
| 04 | Fullstack scaffold | React19/TS/Vite8, Express5 ESM, локальный сервер |
| 05 | Quality gate | npm test, npm run lint, npm run build; общий npm run check |
| 06 | Конфигурация | .env/.env.local, backend vault, PATCH settings, секреты не возвращаются клиенту |
| 07 | Домен | UUID, stages, options, models, assets, costs, logs, минимальная инвалидация; domain tests |
| 08 | Интерфейс | Dark sidebar/header/stepper/cards/dialog, responsive CSS, labels и reduced motion |
| 09 | API и shutdown | Loopback, CSRF, requestId, 400/404/409, lifecycle/shutdown; HTTP integration tests |
| 10 | API client и state | Typed client, abort/timeout, ревизии, последовательное сохранение; browser race test |
| 11 | SQLite | WAL/FULL/STRICT, FK, migrations, CAS revision, integrity и backup; SQLite tests |
| 12 | Файлы | UUID directories, relative paths, atomic saves, очистка временных файлов; traversal/ENOSPC tests |
| 13 | CRUD/settings | Create/PATCH/delete/archive/favorite, PATCH settings, protected revisions, export |
| 14 | Маршруты | History API, reload/back, сохранение этапа, скрытие выключенной анимации; browser test |
| 15 | DOCX | OOXML, ID-based merge, повторы/повреждённый ZIP, 202 строки; parser tests |
| 16 | Создание/draft | Название/язык/template/docs/manual/frames/options, предупреждения импорта, без платных вызовов |
| 17 | Подключения | Две карточки Lumean/fal.ai, status/checkedAt/catalog, очистка password state; browser/API tests |
| 18 | Lumean | Public OpenAPI: X-API-KEY, TTS templates pages, wallets, orders/poll/storage, service alignment; contract tests |
| 19 | Блоки озвучки | Queue1, реальные duration/player, покомпонентное восстановление, неизменённые блоки сохраняются |
| 20 | Свой голос | Project > scene > block, upload validation, skip voiceover, исключение лишнего платного TTS |
| 21 | Медиа/таймлайн | FFprobe + music-metadata fallback, spawn без shell, integer allocation, реальные FFmpeg fixtures |
| 22 | Whisper | Lazy worker/cache, background queue, queued/processing/ready/error/paused, abort/deadline, confidence; worker tests. Качество реального ASR отдельно |
| 23 | Раскадровка | Shot/reply/audio/prompts/camera/weight, autosave/saved/error, approval кадра/сцены, фильтр и collapse |
| 24 | Провайдер fal.ai | Key auth, Platform catalog, прямой upload через официальный SDK, Queue request_id/status/result/cancel, bounded poll/download; fal.ai contract tests |
| 25 | Изображения | Validate → Queue1 → Queue submit → saved request_id → poll → download → magic/decode → PNG → atomic state update |
| 26 | Image UI | Сетка/список, страницы20, ready/error counts, placeholders/loading/broken image/retry/open, batch confirmation |
| 27 | Image-to-video | Локальный PNG загружается напрямую в fal.ai до платного submit; старый URL кадра не нужен. FFprobe/H.264/1080p/30–60FPS/muted, sourceDuration и target duration отдельно |
| 28 | Video queue | Limit2, abort, late-output guards, сохранённые IDs. Удалённая отмена fal.ai не обещается без подтверждённого API |
| 29 | Очереди/restart | Voice1/images1/video2/local1, FIFO, dedupe, restart → paused/uncertain; queue/restart tests |
| 30 | Прогресс/расходы | Детерминированный прогресс, одна запись на попытку, неизвестная стоимость явно неизвестна; failure/restart/cost tests |
| 31 | Субтитры | SRT/VTT, alignment или marked estimate, font/size/position/maxLines/safeArea, выключенный слой не создаёт cues |
| 32 | Remotion | Sequence/Img/OffthreadVideo muted/Audio, integer frames; реальный MP4 E2E |
| 33 | MP4/Studio | Readiness409, фактическая проверка codec/size/fps/duration, Studio с props/media текущего проекта и shutdown |
| 34 | Диагностика | Версия из package.json у клиента/сервера, health/PID/Node/uptime/queues/errors, redacted rotating JSONL |
| 35 | Защита | SECURITY.md, loopback включая Studio, origin/CSRF, path/ZIP/size guards, DNS-pinned HTTPS download, лимиты redirect/bytes/time |
| 36 | Backup/restore | 7 дневных SQLite backup, проверка копии, manifest/media ZIP, restore на новый UUID, integrity CLI без неявного repair |
| 37 | Автотесты | node:test, временные каталоги/ephemeral ports, mock paid APIs, Playwright, настоящие FFmpeg/Remotion |
| 38 | UX/accessibility | Отдельные Create/Settings/ProviderControls/components, dialogs/focus/labels/status, confirmations,20 карточек на странице |
| 39 | Windows | Customer ZIP/manifest/SHA/Node, Install/Start/Stop/Check/Monitor, health before browser, paths with spaces. Чистая VM/AV требуют результатов Windows-приёмки |
| 40 | Update и E2E | Stop/backup/verify/app-only replace/check/start/rollback; backup failure не удаляет data. 3 сцены, изображения/анимация, MP4 30/60FPS, Studio, ZIP/restart и202-frame dry-run |

## Команды и артефакты

- `npm run check`: node:test, oxlint, TypeScript/Vite.
- `node scripts/check-ui.mjs`: создание, переход до debounce, фактический URL/reload, два подключения, разделение image/video моделей fal.ai, TTS-шаблон Lumean, ro/es/pt-BR/pt-PT.
- `node scripts/e2e.mjs`: mock API, настоящие media/render/Studio; test-results/e2e-report.json, three-scenes.mp4, three-scenes-60fps.mp4.
- `npm run package:customer`: release ZIP и SHA-256, все файлы перечислены в package-manifest.json. Проверка пакета не включает user data/env/node_modules.
- Windows workflow: quality gate, PowerShell parser, установка пакета в путь с пробелами, health и повторный Start/Stop. Факт прохождения определяется результатом конкретного Actions run, а не наличием YAML.

## Ручные границы приёмки

1. Реальная генерация, модерация, доступ модели и стоимость на аккаунтах fal.ai/Lumean не подтверждаются mock-тестами. Не вызываем платные API из CI.
2. Произношение/акцент/подача конкретного Lumean-шаблона и качество Whisper требуют прослушивания/сравнения на реальном материале.
3. fal.ai хранит загруженный исходный кадр по своей storage-политике. Встроенный SDK используется на backend; отдельный сторонний файловый хостинг не применяется.
4. Полный перенос ожидающих задач и квитанций обеспечивается backup всего data с SQLite. ZIP проекта предназначен для проверенных медиа/manifest и назначает новый UUID; он не заменяет полный backup приложения.
5. Проверка в Windows developer runner не равна ручной проверке антивируса и совершенно чистой потребительской Windows 10/11. Результаты и ограничения должны оставаться в release report.

Текст: Claude через fal `openrouter/router` подключён отдельной командой в черновике: улучшение/перевод, сравнение, применение с сохранением ID сцен. Unit/HTTP/browser тесты используют mock ответов; оплаченная генерация и качество реальных ответов не проверены. Импорт не вызывает Claude. Анализ/скачивание ссылки YouTube не подключены. Сохранённые части/ID переиспользуются, неизвестный POST не повторяется автоматически; некорректный JSON остаётся квитанцией без изменения сценария.

В0.5 добавлены контракты Nano Banana2/Pro, Kling3 Pro и SeedancePro; загрузка/проверка PNG-образца, передача фактических байтов, запрет несовместимой модели, ограничение длительности до POST, native audio off при поддержке, archive/restore образца. Качество платных результатов и одинаковых персонажей на всём канале автоматические тесты не подтверждают.

В0.6 добавлены три reference-based варианта, выбор/снятие выбора, реальные5-секундные медиа-превью с mock источником, сохранение выбранного стиля после перезапуска/ZIP, передача выбора в production image payload, queued cancel, unknown POST recovery, сохранение повреждённой квитанции без replay, browser selection/reload. Утверждений о качестве реальных платных ответов нет.

В0.6.1 проверяются root/deep-route HTTP200 с готовым frontend и явный503 без него; отсутствующая/старая/повреждённая сборка не признаётся ready. Закрытие тестовых HTTP/SQLite ресурсов выполняется до удаления каталогов. Windows запуск проверяется отдельно от Linux тестов; наличие готовых файлов в ZIP входит в checksum manifest.
