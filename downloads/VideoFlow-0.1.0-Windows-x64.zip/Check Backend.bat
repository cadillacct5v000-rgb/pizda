@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0app\windows\Manage.ps1" -Action Check
if errorlevel 1 pause
