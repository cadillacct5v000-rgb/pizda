@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0app\windows\Manage.ps1" -Action Install
if errorlevel 1 pause
