import {textModels} from './text-models.mjs';
import {createFalClient} from '@fal-ai/client';
import {ensure, AppError, decode64} from './core.mjs';

// Model contracts checked against fal's model API pages. Every endpoint has
// its own input contract; a catalog entry alone does not make it compatible.
export const falEndpoints = {
  'fal-ai/nano-banana-pro': {kind:'image', label:'Nano Banana Pro · Gemini',reference:true},
  'fal-ai/nano-banana-2': {kind:'image', label:'Nano Banana 2 · Gemini',reference:true},
  'fal-ai/bytedance/seedance/v1/pro/image-to-video': {kind:'video', label:'Seedance Pro'},
  'fal-ai/kling-video/v3/pro/image-to-video': {kind:'video', label:'Kling 3 Pro'},
  'openai/gpt-image-2': {kind:'image', label:'GPT Image 2'},
  'fal-ai/flux/dev': {kind:'image', label:'FLUX.1 Dev'},
  'wan/v2.6/image-to-video': {kind:'video', label:'Wan 2.6'},
  'openrouter/router': {kind:'text', label:'GPT через OpenRouter'},
};
export function falModels(response) {
  ensure(Array.isArray(response?.models), 'fal.ai вернул некорректный каталог', 502);
  return response.models.filter((model) => falEndpoints[model.endpoint_id] && model.metadata?.status !== 'deprecated')
    .map((model) => ({value:model.endpoint_id, label:model.metadata?.display_name || falEndpoints[model.endpoint_id].label, kind:falEndpoints[model.endpoint_id].kind, service:'fal'}));
}
export function falQueueRoute(input, config, requestId, suffix = '') {
  let url;
  try {url = new URL(input);} catch {throw new AppError(502, 'fal.ai не вернул корректный адрес задачи');}
  const base = new URL(config.providers.fal.base);
  ensure(url.origin === base.origin && !url.username && !url.password && !url.search && !url.hash && typeof requestId === 'string' && /^[\w-]{1,200}$/.test(requestId) && url.pathname.endsWith(`/requests/${requestId}${suffix}`), 'Небезопасный адрес задачи fal.ai; ID сохранён, новый запрос не отправляется', 502);
  return url.pathname;
}
export function falClient(config, request, download, fetcher = fetch, dependencies = {}) {
  let catalog, key, checked = 0, catalogWarnings = [];
  async function models(force = false) {
    if (!force && catalog && key === config.providers.fal.key && Date.now() - checked < 60000) return catalog;
    catalogWarnings=[];
    const responses = await Promise.all(Object.keys(falEndpoints).map(async (endpoint) => {
      try {const response=await request('fal', `/v1/models?endpoint_id=${encodeURIComponent(endpoint)}`, {base:'https://api.fal.ai'});falModels(response);return response;}
      catch (error) {if(error.status===401||error.details?.providerStatus===401)throw error;if(error.details?.providerStatus!==404)catalogWarnings.push(`Каталог ${endpoint} временно недоступен`);return {models:[]};}
    }));
    ensure(responses.some((r)=>r.models.length),'Каталог fal.ai сейчас недоступен. Попробуйте обновить его позже.',502);
    catalog = [...new Map(responses.flatMap(falModels).map((model) => [model.value,model])).values()]; key = config.providers.fal.key; checked = Date.now(); return catalog;
  }
  async function validate(payload, signal) {
    ensure(['image','video'].includes(payload.stage) && falEndpoints[payload.model]?.kind === payload.stage, 'Выберите модель fal.ai для текущего этапа', 409);
    ensure(typeof payload.prompt === 'string' && payload.prompt.trim(), 'Пустой промпт', 409);
    if (payload.stage === 'image' && payload.reference) ensure(falEndpoints[payload.model]?.reference, 'Образец стиля поддерживается в Nano Banana 2 и Pro. Выберите одну из них или уберите образец.', 409);
    if (payload.model.startsWith('fal-ai/nano-banana')) ensure(payload.prompt.length >= 3 && payload.prompt.length <= 50000, 'Промпт Nano Banana: от 3 до 50000 символов', 409);
    if (payload.stage === 'video') ensure(payload.prompt.length <= 1500 && Number.isFinite(payload.duration) && payload.duration > 0 && payload.image, 'Проверьте изображение, движение (до 1500 символов) и длительность', 409);
    if (payload.stage === 'video') {const limit = payload.model.includes('seedance') ? 12 : 15; ensure(payload.duration <= limit, `Эта модель оживляет до ${limit} секунд за запрос. Разделите сцену на несколько кадров или уменьшите её длительность.`, 409);}
    ensure(falModels(await request('fal', `/v1/models?endpoint_id=${encodeURIComponent(payload.model)}`, {base:'https://api.fal.ai',signal})).some((model) => model.value === payload.model && model.kind === payload.stage), 'Модель fal.ai отсутствует в текущем каталоге', 409);
    signal?.throwIfAborted();
  }
  async function upload(bytes, signal) {
    if (dependencies.upload) return dependencies.upload(bytes, signal);
    const sdk = createFalClient({credentials: config.providers.fal.key.replace(/^Key\s+/i,'').trim(), retry:{maxRetries:0}, fetch:(url,options = {}) => fetcher(url, {...options, redirect:'error', signal:AbortSignal.any([AbortSignal.timeout(config.httpTimeout),signal])})});
    return sdk.storage.upload(new File([bytes], 'frame.png', {type:'image/png'}), {lifecycle:{expiresIn:'1d'}});
  }
  return {
    async check() {return {models:await models(true),textModels:textModels,warnings:catalogWarnings};},
    async validateText(model, signal) {
      ensure(textModels.some((item) => item.value === model), 'Выберите модель GPT из списка', 400);
      const available = falModels(await request('fal','/v1/models?endpoint_id=openrouter%2Frouter',{base:'https://api.fal.ai',signal}));
      ensure(available.some((item) => item.value === 'openrouter/router'), 'Текстовый endpoint fal.ai сейчас недоступен', 409);
      signal?.throwIfAborted();
    },
    // GPT reasoning models do not advertise temperature/top_p/top_k support.
    // Leave optional sampling fields unset instead of forwarding incompatible values.
    async createText({model,prompt,systemPrompt}, signal, checkpoint) {
      ensure(textModels.some((item) => item.value === model), 'Неизвестная модель GPT');
      return this.create({stage:'text',model:'openrouter/router',input:{prompt,system_prompt:systemPrompt,model,max_tokens:16000,reasoning:false}},signal,checkpoint);
    },
    validate,
    async prepare(payload, signal) {
      signal.throwIfAborted();
      if (payload.stage === 'image' && falEndpoints[payload.model]?.reference) {
        const context = [];
        if (payload.reference) context.push({type:'image',image_url:await upload(decode64(payload.reference,25 * 1024 * 1024),signal)});
        return {stage:payload.stage,model:payload.model,input:{prompt:payload.prompt,aspect_ratio:'16:9',resolution:'2K',num_images:1,output_format:'png',...(context.length ? {context,system_prompt:'Use the supplied image as a visual style reference: preserve its palette, linework, shading and recurring character design. Draw the new scene described in the prompt; do not reproduce the reference composition or its embedded text.'} : {})}};
      }
      if (payload.stage === 'image') return {stage:payload.stage,model:payload.model,input:{prompt:payload.prompt,image_size:'landscape_16_9',num_images:1,output_format:'png',...(payload.model === 'openai/gpt-image-2' ? {quality:'medium',background:'opaque'} : {})}};
      const bytes = decode64(payload.image,25 * 1024 * 1024), imageURL = await upload(bytes,signal);
      signal.throwIfAborted();
      const url = new URL(imageURL); ensure(url.protocol === 'https:' && !url.username && !url.password, 'fal.ai не вернул HTTPS-ссылку исходного кадра', 502);
      if (payload.model === 'fal-ai/bytedance/seedance/v1/pro/image-to-video') return {stage:payload.stage,model:payload.model,input:{prompt:payload.prompt,image_url:imageURL,aspect_ratio:'16:9',resolution:'1080p',duration:String(Math.min(12,Math.max(2,Math.ceil(payload.duration)))),camera_fixed:false}};
      if (payload.model === 'fal-ai/kling-video/v3/pro/image-to-video') return {stage:payload.stage,model:payload.model,input:{prompt:payload.prompt,start_image_url:imageURL,duration:String(Math.min(15,Math.max(3,Math.ceil(payload.duration)))),generate_audio:false}};
      return {stage:payload.stage,model:payload.model,input:{prompt:payload.prompt,image_url:imageURL,resolution:'1080p',duration:String([5,10,15].find((duration) => duration >= payload.duration) || 15),enable_prompt_expansion:false,multi_shots:false}};
    },
    async create(prepared, signal, checkpoint) {
      ensure(falEndpoints[prepared.model]?.kind === prepared.stage && prepared.input, 'Неверная задача fal.ai', 409);
      const response = await request('fal', `/${prepared.model}`, {method:'POST',body:prepared.input,signal});
      ensure(typeof response.request_id === 'string', 'fal.ai не вернул ID задачи', 502);
      const descriptor = {stage:prepared.stage,model:prepared.model,requestId:response.request_id,statusURL:response.status_url,responseURL:response.response_url,cancelURL:response.cancel_url};
      const id = JSON.stringify(descriptor); checkpoint?.(id);
      falQueueRoute(descriptor.statusURL,config,descriptor.requestId,'/status');
      falQueueRoute(descriptor.responseURL,config,descriptor.requestId);
      falQueueRoute(descriptor.cancelURL,config,descriptor.requestId,'/cancel');
      return {id};
    },
    async status(externalId, signal) {
      const descriptor = JSON.parse(externalId), route = falQueueRoute(descriptor.statusURL,config,descriptor.requestId,'/status');
      const response = await request('fal',route,{signal});
      if (response.error || ['CANCELLED','FAILED'].includes(response.status)) return {status:'failed'};
      ensure(['IN_QUEUE','IN_PROGRESS','COMPLETED'].includes(response.status), 'fal.ai вернул неизвестный статус задачи', 502);
      return {status:response.status === 'COMPLETED' ? 'succeeded' : 'running', descriptor};
    },
    async result(status, stage, signal) {
      const descriptor = status.descriptor, route = falQueueRoute(descriptor.responseURL,config,descriptor.requestId);
      const result = await request('fal',route,{signal});
      const url = stage === 'image' ? result.images?.[0]?.url : result.video?.url;
      ensure(typeof url === 'string', 'fal.ai не вернул ожидаемый файл; ID задачи сохранён', 502);
      status.resultURL = url;
      return download(url,signal);
    },
    async textResult(status, signal) {
      const descriptor = status.descriptor, route = falQueueRoute(descriptor.responseURL,config,descriptor.requestId);
      const result = await request('fal',route,{signal});
      ensure(typeof result.output === 'string' && result.output.length <= 2 * 1024 * 1024, 'fal.ai не вернул текстовый ответ; ID сохранён', 502);
      const usage = {};
      for (const name of ['prompt_tokens','completion_tokens','total_tokens','cost']) if (Number.isFinite(result.usage?.[name]) && result.usage[name] >= 0) usage[name] = result.usage[name];
      return {output:result.output,partial:result.partial === true,error:!!result.error,usage};
    },
    async cancel(externalId) {
      const descriptor = JSON.parse(externalId), route = falQueueRoute(descriptor.cancelURL,config,descriptor.requestId,'/cancel');
      const result = await request('fal',route,{method:'PUT',signal:AbortSignal.timeout(15000)});
      ensure(result.status === 'OK', 'fal.ai получил запрос отмены, но окончательная отмена и отсутствие списания не подтверждены', 409);
    },
  };
}
