// Verified against fal openrouter/router examples and the public OpenRouter catalog.
// Requests and billing stay on fal.ai; no direct OpenRouter credentials are used.
export const textModels = [
  {value:'openai/gpt-6-sol',label:'GPT-6 Sol'},
  {value:'openai/gpt-6-astra',label:'GPT-6 Astra'},
  {value:'openai/gpt-6-luna',label:'GPT-6 Luna'},
];
export const defaultTextModel = textModels[0].value;
export const currentTextModel = (value) => textModels.some((model) => model.value === value) ? value : defaultTextModel;
