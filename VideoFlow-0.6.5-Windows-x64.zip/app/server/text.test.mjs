import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,readFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {setTimeout as pause} from 'node:timers/promises';
import {AppError} from './core.mjs';
import JSZip from 'jszip';
import {exportArchive,restoreArchive} from './archive.mjs';
import {textService,textBatches,textPrompt,decodeTextResult} from './text.mjs';
import {createProject,importRows,scriptRows,patchProject} from './domain.mjs';
import {configuration} from './config.mjs';
import {openStore} from './database.mjs';
import {falClient} from './fal-client.mjs';
import {createApp} from './app.mjs';

async function settle(service) {for(let i=0;i<300;i++){if(!service.stats().keys.length)return;await pause(5);}throw new Error('Text queue did not settle');}
function setup(t,count=3) {
  const root=mkdtempSync(path.join(tmpdir(),'flow-text-')),config=configuration({DATA_DIR:root},root),store=openStore(root);config.providers.fal.key='mock-key';config.poll=1;config.jobTimeout=1000;
  const project=store.put(importRows(createProject(),scriptRows(Array.from({length:count},(_,i)=>`Реплика ${i+1}.`).join('\n\n'))),null);
  const requests=[],client={validateText:async()=>{},createText:async(input,_signal,checkpoint)=>{const id=String(requests.push(JSON.parse(input.prompt)));checkpoint(id);return {id};},status:async(id)=>({status:'succeeded',id}),textResult:async({id})=>{const input=requests[Number(id)-1];return {output:JSON.stringify({language:input.target_language,blocks:input.blocks.map((b)=>({...b,text:input.target_language==='ru'?`Новая ${b.text}`:`Native sentence ${b.id}`}))}),usage:{cost:.01,total_tokens:100}};},cancel:async()=>{}};
  const service=textService(store,client,config),resources=[];t.after(async()=>{for(const cleanup of resources.reverse())await cleanup();await service.close();store.close();rmSync(root,{recursive:true,force:true});});
  return {root,config,store,project,client,service,requests,cleanup:(fn)=>resources.push(fn),args:{action:'rewrite',model:project.models.falTextModel}};
}
test('text batches preserve IDs and prompts specify native RO/ES/PT narration',()=>{
  const blocks=Array.from({length:19},(_,i)=>({id:String(i),text:'Sentence'}));assert.deepEqual(textBatches(blocks).map((b)=>b.length),[8,8,3]);
  for(const language of ['ro','es','pt-BR','pt-PT']) {const prompt=textPrompt('translate',language,blocks.slice(0,1),'context');assert.equal(JSON.parse(prompt.prompt).target_language,language);assert.match(prompt.systemPrompt,/word order and sentence structure/);assert.match(prompt.systemPrompt,/Keep Brazilian and European Portuguese distinct/);}
  const result={language:'es',blocks:[{id:'1',text:'Hola.'},{id:'0',text:'Una orca.'}]};assert.deepEqual(decodeTextResult({output:JSON.stringify(result)},blocks.slice(0,2),'es').map((b)=>b.id),['0','1']);
  for(const invalid of [{...result,language:'ru'},{...result,blocks:[result.blocks[0],result.blocks[0]]},{...result,blocks:[result.blocks[0]]},{...result,blocks:[{id:'0',text:'<speak>bad</speak>'},result.blocks[0]]},{...result,blocks:[{id:'0',text:'Косатка охотится на тюленей в океане.'},result.blocks[0]]}])assert.throws(()=>decodeTextResult({output:JSON.stringify(invalid)},blocks.slice(0,2),'es'));
  assert.throws(()=>decodeTextResult({output:JSON.stringify(result),partial:true},blocks.slice(0,2),'es'));assert.throws(()=>decodeTextResult({output:'broken'},blocks.slice(0,2),'es'));
});
test('GPT proposal leaves source/assets intact; apply retains IDs/images and backs up old project',async(t)=>{
  const f=setup(t);f.store.mutate(f.project.id,(p)=>{p.frames.forEach((x)=>{x.image={path:'saved.png'};x.video={path:'clip.mp4'};});p.blocks.forEach((b)=>{b.audio={path:'voice.mp3'};});p.uploads.project={path:'own.mp3'};p.uploads[p.blocks[0].sceneId]={path:'scene.mp3'};p.render={path:'render.mp4'};return p;});
  const original=f.store.get(f.project.id),chosen=patchProject(original,{models:{falTextModel:'openai/gpt-6-astra'}});assert.deepEqual(chosen.frames,original.frames);assert.deepEqual(chosen.blocks,original.blocks);assert.deepEqual(chosen.render,original.render);
  const op=f.service.start(f.project.id,f.args);await settle(f.service);let current=f.store.get(f.project.id);assert.deepEqual(current.blocks,original.blocks);assert.deepEqual(current.frames,original.frames);assert.deepEqual(current.render,original.render);assert.equal(current.textProposal.blocks.length,3);
  current=f.service.apply(f.project.id,op.key);assert.deepEqual(current.blocks.map((b)=>b.id),original.blocks.map((b)=>b.id));assert.equal(current.blocks[0].audio,null);assert.equal(current.frames[0].image.path,'saved.png');assert.equal(current.frames[0].video,null);assert.equal(current.render,null);assert.equal(current.uploads.project,undefined);assert.equal(current.uploads[original.blocks[0].sceneId],undefined);assert.equal(current.cost.length,1);assert.equal(current.cost[0].value,.01);
  const history=JSON.parse(readFileSync(path.join(f.root,f.store.operations.get(op.key).beforePath),'utf8'));assert.deepEqual(history.blocks,original.blocks);
});
test('translations RO/ES/PT keep source language until applied and unlink old uploaded narration',async(t)=>{
  for(const language of ['ro','es','pt-BR','pt-PT']) {const f=setup(t,1);f.store.mutate(f.project.id,(p)=>{p.blocks[0].audio={path:'uploaded.mp3',provider:'upload'};p.uploads.project={path:'own.mp3'};return p;});const op=f.service.start(f.project.id,{...f.args,action:'translate',language});await settle(f.service);assert.equal(f.store.get(f.project.id).language,'ru');const result=f.service.apply(f.project.id,op.key);assert.equal(result.language,language);assert.equal(result.blocks[0].audio,null);assert.equal(result.uploads.project,undefined);}
});
test('failed second batch resumes saved ID without resubmitting ready batches, even after restart',async(t)=>{
  const f=setup(t,10),result=f.client.textResult;let fail=true;f.client.textResult=async(s)=>{if(s.id==='2'&&fail)throw new Error('temporary GET error');return result(s);};const op=f.service.start(f.project.id,f.args);await settle(f.service);assert.equal(f.requests.length,2);assert.equal(f.store.operations.get(op.key).completed,1);fail=false;await f.service.close();const restarted=textService(f.store,f.client,f.config);f.cleanup(()=>restarted.close());restarted.start(f.project.id,{...f.args,resumeKey:op.key});await settle(restarted);assert.equal(f.requests.length,2);assert.equal(f.store.operations.get(op.key).status,'ready');assert.equal(f.store.get(f.project.id).textProposal.blocks.length,10);assert.equal(f.store.get(f.project.id).cost.length,2);
});
test('invalid JSON is cached; resuming costs nothing; explicit retry submits only failed batch',async(t)=>{
  const f=setup(t,10),result=f.client.textResult;let invalid=true;f.client.textResult=async(s)=>s.id==='2'&&invalid?{output:'not JSON',usage:{cost:.01}}:result(s);const op=f.service.start(f.project.id,f.args);await settle(f.service);assert.equal(f.requests.length,2);assert.equal(f.store.operations.get(op.key).status,'error');invalid=false;f.service.start(f.project.id,{...f.args,resumeKey:op.key});await settle(f.service);assert.equal(f.requests.length,2);assert.equal(f.store.operations.get(op.key).status,'error');f.service.start(f.project.id,{...f.args,newTake:true,resumeKey:op.key});await settle(f.service);assert.equal(f.requests.length,3);assert.equal(f.store.operations.get(op.key).status,'ready');assert.equal(f.store.get(f.project.id).cost.length,3);
});
test('unknown POST outcome blocks replay; stale continuation and stale apply are rejected',async(t)=>{
  const f=setup(t,1);let sends=0;f.client.createText=async()=>{sends++;throw new Error('lost POST response');};const op=f.service.start(f.project.id,f.args);await settle(f.service);assert.equal(f.store.operations.get(op.key).status,'uncertain');assert.throws(()=>f.service.start(f.project.id,f.args),{status:409});assert.throws(()=>f.service.start(f.project.id,{...f.args,newTake:true}),{status:409});assert.equal(sends,1);f.service.start(f.project.id,{...f.args,newTake:true,acknowledgeUncertain:true});await settle(f.service);assert.equal(sends,2);assert.equal(f.store.get(f.project.id).cost.length,2);
  f.store.mutate(f.project.id,(p)=>patchProject(p,{blocks:[{id:p.blocks[0].id,text:'Изменённый текст.'}]}));assert.throws(()=>f.service.start(f.project.id,{...f.args,resumeKey:op.key}),{status:409});
  const g=setup(t,1);const ready=g.service.start(g.project.id,g.args);await settle(g.service);g.store.mutate(g.project.id,(p)=>patchProject(p,{blocks:[{id:p.blocks[0].id,text:'Изменённый текст.'}]}));assert.throws(()=>g.service.apply(g.project.id,ready.key),{status:409});assert.equal(g.store.get(g.project.id).blocks[0].text,'Изменённый текст.');
});
test('cancellation is persisted and unconfirmed remote cancellation is visible',async(t)=>{
  const f=setup(t,1);let entered;const gate=new Promise((resolve)=>{entered=resolve;});f.client.status=async(_id,signal)=>{entered();await new Promise((resolve,reject)=>{signal.addEventListener('abort',()=>reject(signal.reason),{once:true});});};f.client.cancel=async()=>{throw new Error('not confirmed');};const op=f.service.start(f.project.id,f.args);await gate;assert.equal(f.service.cancel(f.project.id,'script'),1);await settle(f.service);assert.equal(f.store.operations.get(op.key).status,'cancelled');assert.equal(f.store.operations.get(op.key).cancelUnconfirmed,true);assert.equal(f.requests.length,1);
});
test('fal GPT contract uses router, native fields, saved ID and filtered usage',async(t)=>{
  const f=setup(t,1),calls=[],job={request_id:'text-1',status_url:'https://queue.fal.run/openrouter/router/requests/text-1/status',response_url:'https://queue.fal.run/openrouter/router/requests/text-1',cancel_url:'https://queue.fal.run/openrouter/router/requests/text-1/cancel'};
  const client=falClient(f.config,async(_name,route,options={})=>{calls.push({route,options});if(route.includes('/v1/models'))return {models:[{endpoint_id:'openrouter/router'}]};if(options.method==='POST')return job;if(route.endsWith('/status'))return {status:'COMPLETED'};return {output:'{}',partial:true,reasoning:'private',usage:{cost:.02,total_tokens:20,extra:'excluded'}};},async()=>{});
  await client.validateText(f.args.model,new AbortController().signal);let checkpoint;const accepted=await client.createText({model:f.args.model,prompt:'source',systemPrompt:'editor'},new AbortController().signal,(id)=>{checkpoint=id;});assert.equal(checkpoint,accepted.id);const sent=calls.find((c)=>c.options.method==='POST');assert.equal(sent.route,'/openrouter/router');assert.equal(sent.options.body.model,f.args.model);assert.equal(sent.options.body.system_prompt,'editor');assert.equal(sent.options.body.reasoning,false);const result=await client.textResult(await client.status(accepted.id));assert.deepEqual(result,{output:'{}',partial:true,error:false,usage:{cost:.02,total_tokens:20}});
});
test('HTTP text plan/start/proposal/apply and CSRF work with queued mock GPT',async(t)=>{
  const f=setup(t,1);await f.service.close();const runtime=createApp(f.config,{clients:{fal:f.client,lumean:{}}});const server=runtime.app.listen(0,'127.0.0.1');await new Promise((resolve)=>server.once('listening',resolve));f.cleanup(async()=>{await new Promise((resolve)=>server.close(resolve));await runtime.close();});const base=`http://127.0.0.1:${server.address().port}`,state=await(await fetch(`${base}/api/state`)).json();assert.equal(state.textModels.length,3);
  const send=(route,data,csrf=state.csrf)=>fetch(base+route,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(data)});
  const plan=await(await fetch(`${base}/api/projects/${f.project.id}/text/plan`)).json();assert.equal(plan.total,1);assert.equal((await send(`/api/projects/${f.project.id}/text`,f.args,'wrong')).status,403);const response=await send(`/api/projects/${f.project.id}/text`,f.args);assert.equal(response.status,202);const op=await response.json();await settle(runtime.texts);const applied=await send(`/api/projects/${f.project.id}/text/apply`,{operationKey:op.key});assert.equal(applied.status,200);assert.match((await applied.json()).blocks[0].text,/Новая/);
});
test('source edit during inference prevents a stale proposal from replacing the current script',async(t)=>{
  const f=setup(t,1),result=f.client.textResult;let entered,release;const started=new Promise((resolve)=>{entered=resolve;}),gate=new Promise((resolve)=>{release=resolve;});f.client.textResult=async(s)=>{entered();await gate;return result(s);};const op=f.service.start(f.project.id,f.args);await started;f.store.mutate(f.project.id,(p)=>patchProject(p,{blocks:[{id:p.blocks[0].id,text:'Новый сценарий после запуска.'}]}));release();await settle(f.service);assert.equal(f.store.operations.get(op.key).status,'error');assert.equal(f.store.get(f.project.id).textProposal,undefined);assert.equal(f.store.get(f.project.id).blocks[0].text,'Новый сценарий после запуска.');assert.ok(f.store.operations.get(op.key).batches[0].receiptPath);
});
test('queued cancellation makes no POST and restart marks an unknown submit uncertain',async(t)=>{
  const f=setup(t,1);let entered;const started=new Promise((resolve)=>{entered=resolve;});f.client.status=async(_id,signal)=>{entered();await new Promise((resolve,reject)=>signal.addEventListener('abort',()=>reject(signal.reason),{once:true}));};f.service.start(f.project.id,f.args);await started;const other=f.store.put(importRows(createProject(),scriptRows('Другая реплика.')),null);const queued=f.service.start(other.id,f.args);assert.equal(f.service.cancel(other.id,'script'),1);assert.equal(f.store.operations.get(queued.key).status,'cancelled');assert.equal(f.requests.length,1);await f.service.close();
  const op=f.store.operations.get(queued.key);f.store.operations.put({...op,status:'creating',externalId:null});const restarted=textService(f.store,f.client,f.config);f.cleanup(()=>restarted.close());assert.equal(f.store.operations.get(queued.key).status,'uncertain');assert.throws(()=>restarted.start(other.id,f.args),{status:409});
});

test('terminal failure of a saved fal request requires an explicit new submission, retaining ready batches',async(t)=>{
 const f=setup(t,10),original=f.client.textResult;let reject=true;
 f.client.textResult=async(s)=>{if(s.id==='2'&&reject)throw new AppError(502,'fal: HTTP 422 — model: модель недоступна в этом маршруте',{providerStatus:422,terminal:true});return original(s);};
 const op=f.service.start(f.project.id,f.args);await settle(f.service);
 let saved=f.store.operations.get(op.key);assert.equal(saved.completed,1);assert.equal(saved.failure.phase,'result');assert.equal(saved.failure.providerStatus,422);assert.equal(saved.batches[1].externalId,'2');assert.equal(f.requests.length,2);
 assert.throws(()=>f.service.start(f.project.id,f.args),/Новая отправка/);assert.equal(f.requests.length,2);
 reject=false;f.service.start(f.project.id,{...f.args,resumeKey:op.key,newTake:true});await settle(f.service);saved=f.store.operations.get(op.key);assert.equal(saved.status,'ready');assert.equal(f.requests.length,3);assert.equal(f.requests[2].blocks.length,2);assert.equal(saved.failure,null);assert.equal(f.store.get(f.project.id).textProposal.blocks.length,10);
});

test('upgrading a Claude project selects GPT without changing IDs, narration or ready audio and sends no requests',async(t)=>{
 const f=setup(t,1);await f.service.close();
 f.store.mutate(f.project.id,(p)=>{p.models.falTextModel='anthropic/claude-opus-5.5';p.blocks[0].audio={path:'ready-voice.mp3',duration:8,provider:'lumean'};p.frames[0].image={path:'ready-image.png'};return p;});
 const before=f.store.get(f.project.id);let paid=0;f.client.createText=async()=>{paid++;throw new Error('No generation should run during migration');};
 const runtime=createApp(f.config,{clients:{fal:f.client,lumean:{}}});f.cleanup(()=>runtime.close());
 const after=runtime.store.get(f.project.id);assert.equal(after.models.falTextModel,'openai/gpt-6-sol');assert.deepEqual(after.blocks,before.blocks);assert.deepEqual(after.frames,before.frames);assert.equal(paid,0);
 assert.throws(()=>runtime.texts.start(after.id,{action:'rewrite',model:'anthropic/claude-opus-5.5'}),/GPT/);assert.equal(paid,0);
});

test('restoring an old Claude project ZIP migrates to GPT while retaining scene and block bindings',async(t)=>{
 const f=setup(t,3),zip=await JSZip.loadAsync(await exportArchive(f.store,f.project.id));
 const manifest=JSON.parse(await zip.file('manifest.json').async('string'));manifest.models.falTextModel='anthropic/claude-opus-5.5';zip.file('manifest.json',JSON.stringify(manifest));
 const restored=await restoreArchive(f.store,await zip.generateAsync({type:'nodebuffer'}));
 assert.equal(restored.models.falTextModel,'openai/gpt-6-sol');assert.deepEqual(restored.blocks.map(({id,sceneId,text})=>({id,sceneId,text})),f.project.blocks.map(({id,sceneId,text})=>({id,sceneId,text})));assert.deepEqual(restored.frames.map(({id,blockId,sceneId})=>({id,blockId,sceneId})),f.project.frames.map(({id,blockId,sceneId})=>({id,blockId,sceneId})));assert.equal(f.requests.length,0);
});
